
/********************************************************************
 *                                                                     
 *                     Software License Agreement                      
 *                                                                     
 * Copyright (C) 2010  Microchip Technology Inc.  
 * Microchip licenses this software to you solely for use with Microchip
 * products.  The software is owned by Microchip and its licensors, and
 * is protected under applicable copyright laws.  All rights reserved.
 * SOFTWARE IS PROVIDED "AS IS."  MICROCHIP EXPRESSLY DISCLAIMS ANY
 * WARRANTY OF ANY KIND, WHETHER EXPRESS OR IMPLIED, INCLUDING BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT.  IN NO EVENT SHALL MICROCHIP
 * BE LIABLE FOR ANY INCIDENTAL, SPECIAL, INDIRECT OR CONSEQUENTIAL
 * DAMAGES, LOST PROFITS OR LOST DATA, HARM TO YOUR EQUIPMENT, COST OF
 * PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY OR SERVICES, ANY CLAIMS
 * BY THIRD PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF),
 * ANY CLAIMS FOR INDEMNITY OR CONTRIBUTION, OR OTHER SIMILAR COSTS.
 * To the fullest extent allowed by law, Microchip and its licensors
 * liability shall not exceed the amount of fees, if any, that you have
 * paid directly to Microchip to use this software.
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE
 * OF THESE TERMS.
 *                                                                     
 ********************************************************************
 *
 *   Filename:           UNIO PIC33.h
 *   Dependencies:       None
 *   Processor:          dsPIC33FJ256GP710
 *   Compiler:           MPLAB C30 3.23
 *   Date:               March 29, 2010
 *   File Version:       1.0
 *   Author:             Martin Kvasnicka
 *   Company:            Microchip Technology Inc.
 *
 *******************************************************************/

#ifndef __UNIO_DSPIC33_H
#define __UNIO_DSPIC33_H

/** C O N S T A N T   D E F I N I T I O N S ************************/
#define STARTHDR    0x55                // Define STARTHDR as 0x55
#define SAK         1                   // Define SAK as 1
#define NOSAK       0                   // Define NOSAK as 0
#define MAK         1                   // Define MAK as 1
#define NOMAK       0                   // Define NOMAK as 0
#define DEVICE_ADDR 0xA0                // Define DEVICE_ADDR as 0xA0
#define HALF_PERIOD 0x9F                // Timer period, 0x9F = 50 kHz @ 16 MHz Fcy
#define PAGESIZE    16                  // 16-byte page size for 11XXXXX

/** C O M M A N D   D E F I N I T I O N S **************************/
#define WREN        0b10010110          // WREN command
#define WRDI        0b10010001          // WRDI command
#define WRITE       0b01101100          // WRITE command
#define READ        0b00000011          // READ command
#define WRSR        0b01101110          // WRSR command
#define RDSR        0b00000101          // RDSR command
#define ERAL        0b01101101          // ERAL command
#define SETAL       0b01100111          // SETAL command

/** I / O   P I N   D E F I N I T I O N S **************************/
#define SCIO        PORTGbits.RG3       // Serial clock, input/output pin, PORTG pin 3
#define SCIOTRIS    TRISGbits.TRISG3    // SCIO direction bit

/** T Y P E D E F S ************************************************/
typedef union _FLAGS
{
    unsigned char _byte;
    struct
    {
        unsigned sendMAK:1;
        unsigned checkSAK:1;
    };
} FLAGS;

typedef union _STATUSREG
{
    unsigned char _byte;
    struct
    {
        unsigned WIP:1;
        unsigned WEL:1;
        unsigned BP0:1;
        unsigned BP1:1;
    };
} STATUSREG;

typedef union _BYTE
{
    unsigned char _byte;
    struct
    {
        unsigned b0:1;
        unsigned b1:1;
        unsigned b2:1;
        unsigned b3:1;
        unsigned b4:1;
        unsigned b5:1;
        unsigned b6:1;
        unsigned b7:1;
    };
} BYTE;

typedef union _WORD
{
    unsigned int _word;
    struct
    {
        unsigned char byte0;
        unsigned char byte1;
    };
    struct
    {
        BYTE Byte0;
        BYTE Byte1;
    };
    struct
    {
        BYTE LowB;
        BYTE HighB;
    };
    struct
    {
        unsigned char v[2];
    };
} WORD;
#define LSB(a)      ((a).v[0])
#define MSB(a)      ((a).v[1])

/** P R O T O T Y P E S ********************************************/
void ByteWrite(WORD);                           // Byte Write function
void ByteRead(WORD);                            // Byte Read function
void PageWrite(WORD,unsigned char);             // Page Write function
void SeqRead(WORD,unsigned char);               // Sequential Read function
STATUSREG ReadStatusReg(void);                  // Read Status Register function
void WriteStatusReg(STATUSREG);                 // Write Status Register function
void WriteEnable(void);                         // Write Enable function
void WriteDisable(void);                        // Write Disable function
void WIP_Poll(void);                            // WIP polling function
void StandbyPulse(void);                        // Generate Standby Pulse

extern unsigned char pageBuffer[PAGESIZE];      // 16-byte page buffer

#endif
