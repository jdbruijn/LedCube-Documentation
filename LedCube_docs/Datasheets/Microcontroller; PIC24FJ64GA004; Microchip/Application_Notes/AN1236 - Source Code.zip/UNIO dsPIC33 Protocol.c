
/***********************************************************************
 *                                                                     
 *                     Software License Agreement                      
 *
 * Copyright (C) 2010  Microchip Technology Inc.  
 * Microchip licenses this software to you solely for use with Microchip
 * products.  The software is owned by Microchip and its licensors, and
 * is protected under applicable copyright laws.  All rights reserved.
 * SOFTWARE IS PROVIDED "AS IS."  MICROCHIP EXPRESSLY DISCLAIMS ANY
 * WARRANTY OF ANY KIND, WHETHER EXPRESS OR IMPLIED, INCLUDING BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT.  IN NO EVENT SHALL MICROCHIP
 * BE LIABLE FOR ANY INCIDENTAL, SPECIAL, INDIRECT OR CONSEQUENTIAL
 * DAMAGES, LOST PROFITS OR LOST DATA, HARM TO YOUR EQUIPMENT, COST OF
 * PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY OR SERVICES, ANY CLAIMS
 * BY THIRD PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF),
 * ANY CLAIMS FOR INDEMNITY OR CONTRIBUTION, OR OTHER SIMILAR COSTS.
 * To the fullest extent allowed by law, Microchip and its licensors
 * liability shall not exceed the amount of fees, if any, that you have
 * paid directly to Microchip to use this software.
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE
 * OF THESE TERMS.
 *
 ************************************************************************
 *
 *   Filename:           UNIO dsPIC33 Protocol.c
 *   Dependencies:       p33Fxxxx.h
 *                       UNIO dsPIC33.h
 *                       libpic30.h
 *   Processor:          dsPIC33FJ256GP710
 *   Compiler:           MPLAB C30 3.23
 *   Date:               March 29, 2010
 *   File Version:       1.1
 *   Author:             Martin Kvasnicka
 *   Company:            Microchip Technology Inc.
 *
 ** I N C L U D E S ************************************************/

#include <p33Fxxxx.h>
#include <libpic30.h>
#include "UNIO dsPIC33.h"

/** P R I V A T E   P R O T O T Y P E S ****************************/

void _StartHeader(void);                // Output Start Header
void _OutputByte(void);                 // Output a byte
void _OutputHalfBit(void);              // Output half of a bit
void _AckSequence(void);                // Perform Acknowledge Sequence
void _InputByte(void);                  // Input a byte
void _InputBit(void);                   // Input a bit
void _Standby(void);                    // Gracefully enter Standby
void _Tss(void);                        // Observe Tss time period

/** G L O B A L   V A R I A B L E S ********************************/

#pragma udata
BYTE dataOut;                           // 8-bit data output buffer
BYTE dataIn;                            // 8-bit data input buffer
unsigned char count8;                   // 8-bit counter variable
unsigned char pageCount;                // 8-bit page loop counter
unsigned char pageBuffer[PAGESIZE];     // 16-byte page buffer
FLAGS flags;                            // Flag variable

/********************************************************************
 * Function:        void ByteWrite(WORD address)
 *
 * Description:     
 *
 * Parameters:      address - Memory location at which to start
 *******************************************************************/
void ByteWrite(WORD address)
{
    WriteEnable();                  // Set Write Enable Latch
    _Tss();                         // Observe Tss time
    _StartHeader();                 // Output Start Header
    dataOut._byte = DEVICE_ADDR;    // Load DEVICE_ADDR into dataOut
    _OutputByte();                  // Output byte
    dataOut._byte = WRITE;          // Load WRITE into dataOut
    _OutputByte();                  // Output byte
    dataOut._byte = MSB(address);   // Load address MSB into dataOut
    _OutputByte();                  // Output byte
    dataOut._byte = LSB(address);   // Load address LSB into dataOut
    _OutputByte();                  // Output byte
    dataOut._byte = pageBuffer[0];  // Load data into dataOut
    flags.sendMAK = 0;              // Elect to send NoMAK
    _OutputByte();                  // Output byte
    _Standby();                     // Gracefully enter Standby

    WIP_Poll();                     // Perform WIP Polling
} // end of ByteWrite(...)

/********************************************************************
 * Function:        void ByteRead(WORD address)
 *
 * Description:     
 *
 * Parameters:      address - Memory location at which to start
 *******************************************************************/
void ByteRead(WORD address)
{
    _Tss();                         // Observe Tss time
    _StartHeader();                 // Output Start Header
    dataOut._byte = DEVICE_ADDR;    // Load DEVICE_ADDR into dataOut
    _OutputByte();                  // Output byte
    dataOut._byte = READ;           // Load READ into dataOut
    _OutputByte();                  // Output byte
    dataOut._byte = MSB(address);   // Load address MSB into dataOut
    _OutputByte();                  // Output byte
    dataOut._byte = LSB(address);   // Load address LSB into dataOut
    _OutputByte();                  // Output byte
    _InputByte();                   // Input byte
    pageBuffer[0] = dataIn._byte;   // Copy dataIn to pageBuffer
    flags.sendMAK = 0;              // Elect to send NoMAK
    _AckSequence();                 // Perform Acknowledge Sequence
    _Standby();                     // Gracefully enter Standby
} // end of ByteRead(...)

/********************************************************************
 * Function:        void PageWrite(WORD address,
 *                                 unsigned char size)
 *
 * Description:     
 *
 * Parameters:      address - Memory location at which to start
 *                  size - Number of bytes to write
 *******************************************************************/
void PageWrite(WORD address, unsigned char size)
{
    WriteEnable();                  // Set Write Enable Latch
    _Tss();                         // Observe Tss time
    _StartHeader();                 // Output Start Header
    dataOut._byte = DEVICE_ADDR;    // Load DEVICE_ADDR into dataOut
    _OutputByte();                  // Output byte
    dataOut._byte = WRITE;          // Load WRITE into dataOut
    _OutputByte();                  // Output byte
    dataOut._byte = MSB(address);   // Load address MSB into dataOut
    _OutputByte();                  // Output byte
    dataOut._byte = LSB(address);   // Load address LSB into dataOut
    _OutputByte();                  // Output byte

    // Loop through data to write (except last byte)
    for (pageCount = 0; pageCount < size - 1; pageCount++)
    {
        dataOut._byte = pageBuffer[pageCount];// Load next byte
        _OutputByte();              // Output byte
    }
    dataOut._byte = pageBuffer[pageCount];// Load final byte into dataOut
    flags.sendMAK = 0;              // Elect to send NoMAK
    _OutputByte();                  // Output byte
    _Standby();                     // Gracefully enter Standby

    WIP_Poll();                     // Perform WIP Polling
} // end of PageWrite(...)

/********************************************************************
 * Function:        void SeqRead(WORD address,
 *                               unsigned char size)
 *
 * Description:     
 *
 * Parameters:      address - Memory location at which to start
 *                  size - Number of bytes to read
 *******************************************************************/
void SeqRead(WORD address, unsigned char size)
{
    _Tss();                         // Observe Tss time
    _StartHeader();                 // Output Start Header
    dataOut._byte = DEVICE_ADDR;    // Load DEVICE_ADDR into dataOut
    _OutputByte();                  // Output byte
    dataOut._byte = READ;           // Load READ into dataOut
    _OutputByte();                  // Output byte
    dataOut._byte = MSB(address);   // Load address MSB into dataOut
    _OutputByte();                  // Output byte
    dataOut._byte = LSB(address);   // Load address LSB into dataOut
    _OutputByte();                  // Output byte
    _InputByte();                   // Input first byte
    pageBuffer[0] = dataIn._byte;   // Copy dataIn to pageBuffer

    // Loop through remaining data to read (first byte already read)
    for (pageCount = 1; pageCount < size; pageCount++)
    {
        _AckSequence();             // Perform Acknowledge Sequence
        _InputByte();               // Input next byte
        pageBuffer[pageCount] = dataIn._byte;// Copy dataIn to pageBuffer
    }
    flags.sendMAK = 0;              // Elect to send NoMAK
    _AckSequence();                 // Perform Acknowledge Sequence
    _Standby();                     // Gracefully enter Standby
} // end of SeqRead(...)

/********************************************************************
 * Function:        void WriteStatusReg(STATUSREG status)
 *
 * Description:     This function writes the value specified by
 *                  status to the Status Register of a device.
 *                  Note that after performing a WREN instruction, a
 *                  RDSR instruction is executed to check that the
 *                  WEL bit is set. However, currently no error-
 *                  handling is done if the WEL bit is not set.
 *
 * Parameters:      status - Value to be written to Status Register
 *******************************************************************/
void WriteStatusReg(STATUSREG status)
{
    WriteEnable();                  // Set Write Enable Latch
    _Tss();                         // Observe Tss time
    _StartHeader();                 // Output Start Header
    dataOut._byte = DEVICE_ADDR;    // Load DEVICE_ADDR into dataOut
    _OutputByte();                  // Output byte
    dataOut._byte = WRSR;           // Load WRSR into dataOut
    _OutputByte();                  // Output byte
    dataOut._byte = status._byte;   // Load status reg value into dataOut
    flags.sendMAK = 0;              // Elect to send NoMAK
    _OutputByte();                  // Output byte
    _Standby();                     // Gracefully enter Standby

    WIP_Poll();                     // Perform WIP Polling
} // end of WriteStatusReg(...)

/********************************************************************
 * Function:        STATUSREG ReadStatusReg(void)
 *
 * Description:     This function reads and returns the value of the
 *                  Status Register of a device.
 *******************************************************************/
STATUSREG ReadStatusReg(void)
{
    static STATUSREG retVal;        // Return value

    _Tss();                         // Observe Tss time
    _StartHeader();                 // Output Start Header
    dataOut._byte = DEVICE_ADDR;    // Load DEVICE_ADDR into dataOut
    _OutputByte();                  // Output byte
    dataOut._byte = RDSR;           // Load RDSR into dataOut
    _OutputByte();                  // Output byte
    _InputByte();                   // Input byte
    retVal._byte = dataIn._byte;    // Copy status reg value to retVal
    flags.sendMAK = 0;              // Elect to send NoMAK
    _AckSequence();                 // Perform Acknowledge Sequence
    _Standby();                     // Gracefully enter Standby

    return retVal;                  // Return retVal
} // end of ReadStatusReg(void)

/********************************************************************
 * Function:        void WriteEnable(void)
 *
 * Description:     This function performs a Write Enable instruction
 *                  to set the WEL bit in the Status Register.
 *******************************************************************/
void WriteEnable(void)
{
    _Tss();                         // Observe Tss time
    _StartHeader();                 // Output Start Header
    dataOut._byte = DEVICE_ADDR;    // Load DEVICE_ADDR into dataOut
    _OutputByte();                  // Output byte
    dataOut._byte = WREN;           // Load WREN into dataOut
    flags.sendMAK = 0;              // Elect to send NoMAK
    _OutputByte();                  // Output byte
    _Standby();                     // Gracefully enter Standby
} // end of WriteEnable(void)

/********************************************************************
 * Function:        void WriteDisable(void)
 *
 * Description:     This function performs a Write Disable instruction
 *                  to clear the WEL bit in the Status Register.
 *******************************************************************/
void WriteDisable(void)
{
    _Tss();                         // Observe Tss time
    _StartHeader();                 // Output Start Header
    dataOut._byte = DEVICE_ADDR;    // Load DEVICE_ADDR into dataOut
    _OutputByte();                  // Output byte
    dataOut._byte = WRDI;           // Load WRDI into dataOut
    flags.sendMAK = 0;              // Elect to send NoMAK
    _OutputByte();                  // Output byte
    _Standby();                     // Gracefully enter Standby
} // end of WriteDisable(void)

/********************************************************************
 * Function:        void WIP_Poll(void)
 *
 * Description:     This function performs WIP polling to determine
 *                  the end of the current write cycle. It does this
 *                  by continuously executing a Read Status Register
 *                  operation until the WIP bit (bit 0 of the Status
 *                  Register) is read low.
 *******************************************************************/
void WIP_Poll(void)
{
    _Tss();                         // Observe Tss time
    _StartHeader();                 // Output Start Header
    dataOut._byte = DEVICE_ADDR;    // Load DEVICE_ADDR into dataOut
    _OutputByte();                  // Output byte
    dataOut._byte = RDSR;           // Load RDSR into dataOut
    _OutputByte();                  // Output byte
    _InputByte();                   // Input byte
    while (dataIn.b0 == 1)
    {
        _AckSequence();             // Perform Acknowledge Sequence
        _InputByte();               // Input byte
    }
    flags.sendMAK = 0;              // Elect to send NoMAK
    _AckSequence();                 // Perform Acknowledge Sequence
    _Standby();                     // Gracefully enter Standby
} // end of WIP_Poll(void)

/********************************************************************
 * Function:        void StandbyPulse(void)
 *
 * Description:     Hold SCIO high for Tstby time period to generate
 *                  standby pulse. This subroutine will delay for a
 *                  total of 600 us (9600 insts.) after setting SCIO
 *                  high.
 *******************************************************************/
void StandbyPulse(void)
{
    SCIO = 1;                       // Ensure SCIO is high
    SCIOTRIS = 0;                   // Ensure SCIO is driving

    __delay32(9600);                // Delay for Tstby time
} // end of StandbyPulse(void)

/********************************************************************
 * Function:        void _StartHeader(void)
 *
 * Description:     Hold SCIO low for Thdr time period and output
 *                  Start Header ('01010101'). For the low pulse,
 *                  this subroutine will delay for a total of 5 us
 *                  (50 insts.), including the call to OutputByte.
 *******************************************************************/
void _StartHeader(void)
{
    SCIO = 0;                       // Set SCIO low
    SCIOTRIS = 0;                   // Ensure SCIO is driving
    dataOut._byte = STARTHDR;       // Load Start Header value into dataOut
    IFS0bits.T1IF = 0;              // Clear T1IF flag
    TMR1 = HALF_PERIOD - 8;         // Load TMR1 with HALF_PERIOD-8 to minimize
                                    //   time before 1st bit
    flags.sendMAK = 1;              // Elect to send MAK bit
    flags.checkSAK = 0;             // Elect to not check for SAK bit
    T1CONbits.TON = 1;              // Enable Timer1
    _OutputByte();                  // Output byte
    flags.checkSAK = 1;             // Elect to check for SAK bit
} // end of _StartHeader(void)

/********************************************************************
 * Function:        void _OutputByte(void)
 *
 * Description:     Manchester-encodes & outputs the value in dataOut to
 *                  SCIO.
 *******************************************************************/
void _OutputByte(void)
{
    // Loop through byte
    for (count8 = 0; count8 < 8; count8++)
    {
        _OutputHalfBit();           // Output first half of bit
        _OutputHalfBit();           // Output second half of bit
        dataOut._byte <<= 1;        // Shift data left 1 bit
    }

    _AckSequence();                 // Perform Acknowledge Sequence
} // end of _OutputByte(void)

/********************************************************************
 * Function:        void _OutputHalfBit(void)
 *
 * Description:     Waits until Timer 1 rolls over, then outputs the
 *                  next half of the current bit period. The value
 *                  used is specified by the MSb of dataOut.
 *******************************************************************/
void _OutputHalfBit(void)
{
    while (IFS0bits.T1IF == 0) {};  // Wait until T1IF flag is set

    SCIOTRIS = 0;                   // Ensure SCIO is outputting
    if (dataOut.b7 == 1)            // Check if dataOut MSb is 1
        SCIO = 0;                   // If 1, set SCIO low
    else
        SCIO = 1;                   // If 0, set SCIO high

    IFS0bits.T1IF = 0;              // Clear T1IF flag
    dataOut._byte = ~dataOut._byte; // Invert dataOut for next half
} // end of _OutputHalfBit(void)

/********************************************************************
 * Function:        void _AckSequence(void)
 *
 * Description:     Performs Acknowledge sequence, including
 *                  MAK/NoMAK as specified by SEND_MAK flag, and SAK.
 *******************************************************************/
void _AckSequence(void)
{
    // Prepare for sending MAK bit
    dataOut.b7 = 1;                 // Assume MAK will be sent
    if (flags.sendMAK == 0)         // Check if MAK is to be sent
        dataOut.b7 = 0;             // If not sending MAK, clear data bit

    // Send MAK/NoMAK bit
    _OutputHalfBit();               // Output first half of bit
    _OutputHalfBit();               // Output second half of bit

    // Release SCIO at end of bit period
    while (IFS0bits.T1IF == 0) {};  // Wait until T1IF flag is set
    IFS0bits.T1IF = 0;              // Clear T1IF flag
    SCIOTRIS = 1;                   // Set SCIO to be an input

    // Determine if SAK is to be checked
    if (flags.checkSAK == 1)        // Check if expecting SAK
    {
        _InputBit();                // Input SAK bit
    }
    else
    {
        // Not expecting SAK, delay until past half of bit period
        while (IFS0bits.T1IF == 0) {};// Wait until T1IF flag is set
        IFS0bits.T1IF = 0;          // Clear T1IF flag
    }    
} // end of _AckSequence(void)

/********************************************************************
 * Function:        void _InputByte(void)
 *
 * Description:     Inputs and Manchester-decodes from SCIO a byte
 *                  of data and stores it in dataIn.
 *******************************************************************/
void _InputByte(void)
{
    // Loop through byte
    for (count8 = 0; count8 < 8; count8++)
    {
        while (IFS0bits.T1IF == 0) {};// Wait until T1IF flag is set
        dataIn._byte <<= 1;         // Shift dataIn left to prepare for next bit
        _InputBit();                // Input bit
    }
} // end of _InputByte(void)

/********************************************************************
 * Function:        void _InputBit(void)
 *
 * Description:     Inputs and Manchester-decodes from SCIO a bit of
 *                  data and stores it in the LSb of dataIn.
 *******************************************************************/
void _InputBit(void)
{
    IFS0bits.T1IF = 0;              // Clear T1IF flag

    // Add 1/4th period to TMR1 to offset by 1/4th bit period
    TMR1 += (HALF_PERIOD/2+1);      // Add (HALF_PERIOD/2)+1 to TMR1 (+1 necessary due to lost clock)

    // Wait until flag is set, indicating we are 1/4th into bit period
    while (IFS0bits.T1IF == 0) {};  // Wait until T1IF flag is set
    IFS0bits.T1IF = 0;              // Clear T1IF flag

    // Wait until flag is set, indicating we are 3/4th into bit period
    while (IFS0bits.T1IF == 0) {};  // Wait until T1IF flag is set
    IFS0bits.T1IF = 0;            // Clear T1IF flag

    dataIn.b0 = 1;                  // Assume data bit is 1
    if (SCIO == 0)                  // Check if SCIO is 0
        dataIn.b0 = 0;              // If 0, clear data bit

    // Add 1/4th period to TMR1 to offset by 1/4th bit period
    TMR1 += (HALF_PERIOD/2+1);      // Add (HALF_PERIOD/2)+1 to TMR1 (+1 necessary due to lost clock)
} // end of _InputBit(void)

/********************************************************************
 * Function:        void _Standby(void)
 *
 * Description:     Waits until end of current bit period has been
 *                  reached, ensures SCIO is high for bus idle, and
 *                  disables Timer1
 *******************************************************************/
void _Standby(void)
{
    while (IFS0bits.T1IF == 0) {};  // Wait until T1IF flag is set
    IFS0bits.T1IF = 0;              // Clear T1IF flag
    T1CONbits.TON = 0;              // Disable Timer1
    SCIO = 1;                       // Ensure SCIO is high for bus idle
    SCIOTRIS = 0;                   // Ensure SCIO is outputting
} // end of _Standby(void)

/********************************************************************
 * Function:        void _Tss(void)
 *
 * Description:     Hold SCIO high for Tss time period (10 us or
 *                  160 insts), including return.
 *******************************************************************/
void _Tss(void)
{
    __delay32(160);                 // Delay for Tss time period
} // end of _Tss(void)
