
/***********************************************************************
 *                                                                     
 *                     Software License Agreement                      
 *                                                                     
 * Copyright (C) 2010  Microchip Technology Inc.  
 * Microchip licenses this software to you solely for use with Microchip
 * products.  The software is owned by Microchip and its licensors, and
 * is protected under applicable copyright laws.  All rights reserved.
 * SOFTWARE IS PROVIDED "AS IS."  MICROCHIP EXPRESSLY DISCLAIMS ANY
 * WARRANTY OF ANY KIND, WHETHER EXPRESS OR IMPLIED, INCLUDING BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT.  IN NO EVENT SHALL MICROCHIP
 * BE LIABLE FOR ANY INCIDENTAL, SPECIAL, INDIRECT OR CONSEQUENTIAL
 * DAMAGES, LOST PROFITS OR LOST DATA, HARM TO YOUR EQUIPMENT, COST OF
 * PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY OR SERVICES, ANY CLAIMS
 * BY THIRD PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF),
 * ANY CLAIMS FOR INDEMNITY OR CONTRIBUTION, OR OTHER SIMILAR COSTS.
 * To the fullest extent allowed by law, Microchip and its licensors
 * liability shall not exceed the amount of fees, if any, that you have
 * paid directly to Microchip to use this software.
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE
 * OF THESE TERMS.
 *                                                                     
 ************************************************************************
 *
 *   Filename:           UNIO PIC33.c
 *   Dependencies:       p33Fxxxx.h
 *                       UNIO dsPIC33.h
 *   Processor:          dsPIC33FJ256GP710
 *   Compiler:           MPLAB C30 3.23
 *   Date:               March 29, 2010
 *   File Version:       1.0
 *   Author:             Martin Kvasnicka
 *   Company:            Microchip Technology Inc.
 *
 ************************************************************************
 *
 *   Purpose:
 *
 *   This application note is intended to serve as a reference for
 *   manually communicating with Microchip�s UNI/O(R) bus-compatible
 *   11XXXXX family of serial EEPROM devices. Communication is performed
 *   through software control.
 *
 ************************************************************************
 *
 *   Program Description:
 *
 *   This program illustrates page write and read operations, as well as
 *   the Write Enable instruction and the WIP Polling feature. Note that
 *   no action is taken if a SAK bit is not received when one is
 *   expected.
 *
 ************************************************************************
 *
 *   8 MHz crystal oscillator with PLL is being used, thus each
 *   instruction cycle = 62.5 ns
 *
 *   PORTG Pin Descriptions:
 *
 *   SCIO        bit = 3
 *
 ** I N C L U D E S ****************************************************/

#include <p33Fxxxx.h>
#include "UNIO dsPIC33.h"

/** C O N F I G ********************************************************/

_FGS(GSS_OFF & GWRP_OFF);                       // Code Protect off, Write protect disabled
_FOSCSEL(FNOSC_PRIPLL & IESO_OFF);              // Prim. Osc (XT, HS, EC) w/ PLL, Two speed osc off
_FOSC(FCKSM_CSDCMD & OSCIOFNC_OFF & POSCMD_HS); // Clock Switch & Clock Monitor off, Osc 2 clock, High Speed
_FWDT(FWDTEN_OFF);                              // Watchdog Timer Disabled

/** P R O T O T Y P E S ************************************************/
void init(void);                                // Init. function

void main(void)
{
    static unsigned char i;                     // Loop counter
    static WORD address;                        // Address value

    init();                                     // Initialize PIC

    pageBuffer[0] = 0xCC;                       // Initialize first data byte

    address._word = 0x133;                      // Set address to 0x133
    ByteWrite(address);                         // Write 1 byte of data at 0x133
    pageBuffer[0] = 0xFF;
    ByteRead(address);                          // Read 1 byte of data at 0x133

    for (i = 0; i < PAGESIZE; i++)              // Initialize data array
    {
        pageBuffer[i] = i;
    }

    address._word = 0x150;                      // Set address to 0x150
    PageWrite(address, PAGESIZE);               // Write 1 page of data starting at 0x150
    for (i = 0; i < PAGESIZE; i++)              // Initialize data array
    {
        pageBuffer[i] = 0xFF;
    }
    SeqRead(address, PAGESIZE);                 // Read 1 page of data starting at 0x150

    while(1){};                                 // Loop here forever
} // end main(void)

/********************************************************************
 * Function:        void init(void)
 *
 * Description:     This function initializes the PIC MCU.
 *******************************************************************/
void init(void)
{
    // Initialize PLL
    CLKDIV = 0b0000000001000000;        // PLLPRE = 2, PLLPOST = 4
    PLLFBD = 0x1E;                      // PLLDIV = 32
    // Initialize I/O
    AD1PCFGH = 0xFFFF;                  // Disable analog inputs
    SCIO = 0;                           // Set SCIO to drive low
    SCIOTRIS = 0;                       // Configure SCIO to output
    Nop();                              // Delay to ensure minimum pulse width of 125 ns
    SCIO = 1;                           // Bring SCIO high to release from POR
    // Initialize Timer1
    T1CON = 0b0000000000000000;         // Configure Timer1, 1:1 prescalar, internal clock
    PR1 = HALF_PERIOD;                  // Load HALF_PERIOD into PR1
    TMR1 = 0x00;                        // Clear TMR1

    StandbyPulse();                     // Generate Standby Pulse
} // end init(void)
