/************************************************************************	
 *																	   	*
 *            PIC 24 Memory interface using PMP							*
 *																		*
 ************************************************************************	
 * FileName:        MemIntfExample.c
 * Dependencies:    See INCLUDES section below
 * Processor:       PIC24
 * Compiler:        C30 1 31
 * Company:         Microchip Technology, Inc 
 *
 * Software License Agreement
 *
 * The software supplied herewith by Microchip Technology Incorporated
 * (the �Company�) for its PICmicro� Microcontroller is intended and
 * supplied to you, the Company�s customer, for use solely and
 * exclusively on Microchip PICmicro Microcontroller products  The
 * software is owned by the Company and/or its supplier, and is
 * protected under applicable copyright laws  All rights are reserved 
 * Any use in violation of the foregoing restrictions may subject the
 * user to criminal sanctions under applicable laws, as well as to
 * civil liability for the breach of the terms and conditions of this
 * license 
 *
 * THIS SOFTWARE IS PROVIDED IN AN �AS IS� CONDITION  NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
 * TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE APPLY TO THIS SOFTWARE  THE COMPANY SHALL NOT,
 * IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
 * CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER 
 *
 *======================================================================*
 * Author               Date        Comment								*
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*
 * Vidyadhar		  11/02/06	    Original							*
 ***********************************************************************/

/** I N C L U D E S ****************************************************/
//#include <p24FJ128GA010.h>
#include <p24Fxxxx.h>
#include "MemInterface.h"

unsigned char MemWdata[129];							//Buffer to store data to be written to memory
unsigned char MemRdata[129];							//Buffer to store data read from memory

#pragma code


int main(void)
{
unsigned char Variable;

	PMPInit();								//Initialize PMP

	MemByteWrite(0x5555, 0xaa);				//Write 0xAA at 0x5555
	MemByteWrite(0x2aaa, 0x55);				//Write 0x55 at 0x2AAA
	MemBulkWrite(0x0000, 128, MemWdata);	//Write 128 bytes of data in buffer into memory from loc 0x0000

	Delay();								//call a delay if required

	Variable = MemByteRead(0x5555);			//Read  the data from 0x5555
	MemBulkRead(0x0000, 128, MemRdata);	//read 128 bytes of data from memory starting from loc 0x0000

	while(1);
}											//and save in the buffer




//Write a delay routine to allow the data to be written into 
//memory if FLASH device is used.

Delay(void)
{
	long int i;
	for(i=0; i <=3636; i++);				//10ms second delay for 8MHz
}
