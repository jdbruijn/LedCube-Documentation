/** P R O T O T Y P E S ******************************************************/
void PMPInit(void);
char MemByteRead(unsigned long Address);
void MemBulkRead(unsigned long Address, unsigned int Length, unsigned char *SaveAdrs);
void MemByteWrite(unsigned long Address, unsigned char Data);
void MemBulkWrite(unsigned long Address, unsigned int Length, unsigned char *SrcAdrs);
