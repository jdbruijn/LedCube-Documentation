
/************************************************************************	
 *																	   	*
 *            PIC 24 Memory interface using PMP							*
 *																		*
 ************************************************************************	
 * FileName:        MemInterface c
 * Dependencies:    See INCLUDES section below
 * Processor:       PIC24
 * Compiler:        C30 1 31
 * Company:         Microchip Technology, Inc 
 *
 * Software License Agreement
 *
 * The software supplied herewith by Microchip Technology Incorporated
 * (the �Company�) for its PICmicro� Microcontroller is intended and
 * supplied to you, the Company�s customer, for use solely and
 * exclusively on Microchip PICmicro Microcontroller products  The
 * software is owned by the Company and/or its supplier, and is
 * protected under applicable copyright laws  All rights are reserved 
 * Any use in violation of the foregoing restrictions may subject the
 * user to criminal sanctions under applicable laws, as well as to
 * civil liability for the breach of the terms and conditions of this
 * license 
 *
 * THIS SOFTWARE IS PROVIDED IN AN �AS IS� CONDITION  NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
 * TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE APPLY TO THIS SOFTWARE  THE COMPANY SHALL NOT,
 * IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
 * CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER 
 *
 *======================================================================*
 * Author               Date        Comment								*
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*
 * Vidyadhar		  24/June/08	    Original						*
 ***********************************************************************/

/** I N C L U D E S ****************************************************/
#include <p24Fxxxx.h>
#include "MIDefn.h"


/** D E F I N I T I O N S **********************************************/

#define LOW(a)	a

#define HIGH(a) ((a>>15) & 0x00FF)


/** V A R I A B L E S ********************************************************/
#pragma udata

#if defined SingleMorethan32KB
unsigned char Address_High;
#endif

#if defined More16KB
unsigned char Chip_Select;
#endif


/** D E C L A R A T I O N S **************************************************/
#pragma code

/******************************************************************************
 * Function:        void PMPInit(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None 
 *
 * Overview:        Initializes PMP module to interface with memory 
 *
 *****************************************************************************/
void PMPInit(void)
{
	PMMODE = 0x0200;						//Select Master mode with Read & Write on 2 separate pins

											//Select the delays
	PMMODE |= (((SetDataSetupWait_TCY-1)*64)|(SetControlWidthWait_TCY*4)|(SetDataHoldWait_TCY-1));

	PMCON = 0x8320;							//Enable PMP, Enable Write, Read ports, select ALE polarity high. 

	#if defined FullAddressDataMux
  	  PMCONbits.ADRMUX = 2;					//Select Full address multiplexed with Data
  	  PMAEN = 0x0003;						//Enable ALEL & ALEH ports

	#elif defined LowAddressDataMux
  	  PMCONbits.ADRMUX = 1;					//Select Low address multiplexed with Data
  	  PMAEN = 0xFF01;						//Enable ALEL & High address (A15:A8) ports

	#elif defined AddressDataNoMux
  	  PMCONbits.ADRMUX = 0;					//Select No address multiplexed with Data
  	  PMAEN = 0xFFFF;						//Enable address (A15:A0) ports
	#endif

	#if defined Single64KBChipNoCS
	  PMCONbits.CSF = 0;					//Select No Chip selects

	#elif defined Two16KBChips
	  PMCONbits.CSF = 2;					//Select 2 Chip selects
  	  PMAEN |= 0xC000;						//Enable PMCS1 & PMCS2 ports

	#else
	  PMCONbits.CSF = 1;					//Select 1 Chip select
  	  PMAEN |= 0x8000;						//Enable PMCS2 port
	#endif

	#if defined SingleMorethan32KBChip
int *Trisx;

	  Trisx = (int *)(&AddressHighPort-2);	//Make PORT used for AddressHigh, output
	  AddressHighPort &= AdrsPinNo;			//Drive zeros on PORT used for AddressHigh 	
	  *Trisx &= AdrsPinNo;

	#endif

	#if defined More32KBChips
int *Trisx;

	  Trisx = (int *)(&ChipSelectPort-2);	//Make PORT used for ChipSelect, output
	  ChipSelectPort &= CSPinNo;			//Drive zeros on PORT used for ChipSelect
	  *Trisx &= CSPinNo;

	#endif

	#if defined Data16bit
	  PMMODEbits.MODE16 = 1;				//If 16-bit memory is used select MODE16

	  #if defined HighByteEnb
	    PMCONbits.BEP = 1;					//If Active high Byte-Enable required set it
	  #endif
	#endif

}// end PMPInit



/******************************************************************************
 * Function:        char MemByteRead(Address)
 *
 * PreCondition:    PMPInit should have been called
 *
 * Input:           Address of the memory location
 *
 * Output:          Data form memory
 *
 * Side Effects:    None
 *
 * Overview:        The data is read from the specified location and returned 
 *
 *****************************************************************************/
char MemByteRead(unsigned long Address)
{
unsigned int Temp;

	while(PMMODEbits.BUSY);					//wait till PMP is busy

	#if defined (Single64KBChipNoCS)
	  PMADDR = Address;						//load Address to PMADDR

	#elif (defined Single32KBChip)||(defined Single16KB)
	  PMADDR = Address;						//load Address to PMADDR
	  asm ("bset PMADDR, #15");				//enable PMCS2

	#elif (defined Two16KBChips)
	  PMADDR = Address;						//load Address to PMADDR
	  if (Address >= 0x4000)
	    asm ("bset PMADDR, #15");			//enable PMCS2
	  else
	    asm ("bset PMADDR, #14");			//enable PMCS1

	#elif (defined SingleMorethan32KBChip)
	  PMADDR = LOW(Address);				//load Address to PMADDR
	  asm ("bset PMADDR, #15");				//enable PMCS2
	  
	  AddressHighPort |= HIGH(Address);		//load Address_high to AddressHighPORT
	  AddressHighPort &= (AdrsPinNo | HIGH(Address));

	#elif (defined More32KBChips)
	  PMADDR = LOW(Address);				//load Address to PMADDR
	  asm ("bset PMADDR, #15");				//enable PMCS2

	  ChipSelectPort |= HIGH(Address);		//load Address_high to ChipSelectPORT
	  ChipSelectPort &= (CSPinNo | HIGH(Address));
	#endif
	
	Temp = PMDIN1;							//do a dummy read to initialize the read
	while(PMMODEbits.BUSY);					//wait till PMP is busy
	return(PMDIN1);							//return the data read

}// end MemByteRead


/******************************************************************************
 * Function:        void MemBulkRead(Address, Length, SaveAdrs)
 *
 * PreCondition:    PMPInit should have been called
 *
 * Input:           Starting Address of the memory location, Number of bytes to be read, Location from where the read data to be stored 
 *
 * Output:          Read data are stored from specified location
 *
 * Side Effects:    None
 *
 * Overview:        The data ares read from the specified locations and saved at specifed locations
 *
 *****************************************************************************/
void MemBulkRead(unsigned long Address, unsigned int Length, unsigned char *SaveAdrs)
{
	unsigned int Temp;

	while(PMMODEbits.BUSY);					//wait till PMP is busy
	SetAddressAutoInc();					//Set address auto increment
    PMADDR = Address;						//load Address to PMADDR

	#if (defined Two16KBChips)
	  if (Address >= 0x4000)
	    asm ("bset PMADDR, #15");			//enable PMCS2
	  else
	    asm ("bset PMADDR, #14");			//enable PMCS1

	#else 
	  #if defined (Single64KBChipNoCS) 
	    Nop();
	  #else  
	   	asm ("bset PMADDR, #15");			//enable PMCS2

		#if (defined SingleMorethan32KBChip)
		  AddressHighPort |= HIGH(Address);	//load Address_high to AddressHighPORT
	  	  AddressHighPort &= (AdrsPinNo | HIGH(Address));

		#elif (defined More32KBChips)
		  ChipSelectPort |= HIGH(Address);	//load Address_high to ChipSelectPORT
	 	  ChipSelectPort &= (CSPinNo | HIGH(Address));
	    #endif	
	  #endif
	#endif

	while(PMMODEbits.BUSY);					//wait till PMP is busy
	*SaveAdrs = PMDIN1;						//do a dummy read to initialize the read

	for(Temp = 0;Temp<=Length;Temp++)
	{
		while(PMMODEbits.BUSY);				//wait till PMP is busy
		
		*SaveAdrs++ = PMDIN1;				//read and increment the pointer

    	while(PMMODEbits.BUSY);				//wait till PMP is busy
		#if (defined Two16KBChips)
	  	  if (PMADDR == 0x4000)
		  {	
	    	asm ("bclr PMADDR, #14");		//disable PMCS1
	    	asm ("bset PMADDR, #15");		//enable PMCS2
		  }

		#elif (defined SingleMorethan32KBChip)
		  if(PMADDR == 0x8000)
											//check for address max and if so roll over
	  		if((AddressHighPort & (AdrsPinNo^0xFFFF)) == (AdrsPinNo^0xFFFF))
			  AddressHighPort &= AdrsPinNo;

			else
		      AddressHighPort ++;			//increment the AddressHighPORT

		#elif defined (More32KBChips) 
		  if(PMADDR == 0x8000)
											//check for ChipSelect max and if so roll over
	  		if((ChipSelectPort & (CSPinNo^0xFFFF)) == (CSPinNo^0xFFFF))
			  ChipSelectPort &= CSPinNo;
			else
		      ChipSelectPort ++;			//increment the ChipSelectPORT
		#endif
	}
}// end MemBulkRead




/******************************************************************************
 * Function:        MemByteWrite(Address, Data)
 *
 * PreCondition:    PMPInit should have been called
 *
 * Input:           Address of the memory location, The data to be written
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        
 *
 * Note:            None
 *****************************************************************************/
void MemByteWrite(unsigned long Address, unsigned char Data)
{

	while(PMMODEbits.BUSY);					//wait till PMP is busy
	#if defined (Single64KBChipNoCS)
	  PMADDR = Address;						//load Address to PMADDR

	#elif (defined Single32KBChip)||(defined Single16KB)
	  PMADDR = Address;						//load Address to PMADDR
	  asm ("bset PMADDR, #15");				//enable PMCS2

	#elif (defined Two16KBChips)
	  PMADDR = Address;						//load Address to PMADDR
	  if (Address >= 0x4000)
	    asm ("bset PMADDR, #15");			//enable PMCS2
	  else
	    asm ("bset PMADDR, #14");			//enable PMCS1

	#elif (defined SingleMorethan32KBChip)
	  PMADDR = LOW(Address);				//load Address to PMADDR
	  asm ("bset PMADDR, #15");				//enable PMCS2
      AddressHighPort |= HIGH(Address);		//load Address_high to AddressHighPORT
	  AddressHighPort &= (AdrsPinNo | HIGH(Address));

	#elif defined (More32KBChips)
	  PMADDR = LOW(Address);				//load Address to PMADDR
	  asm ("bset PMADDR, #15");				//enable PMCS2
      ChipSelectPort |= HIGH(Address);		//load Address_high to ChipSelectPORT
	  ChipSelectPort &= (CSPinNo | HIGH(Address));
	#endif

	while(PMMODEbits.BUSY);					//wait till PMP is busy
	PMDIN1 = Data;							//write the Data

}//end MemByteWrite



/******************************************************************************
 * Function:        void MemBulkWrite(Address, Length, SrcAdrs)
 *
 * PreCondition:    PMPInit should have been called
 *
 * Input:           Starting Address of the memory location, Number of bytes to be written, Location from where the data to be written is stored 
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        
 *
 * Note:            None
 *****************************************************************************/
void MemBulkWrite(unsigned long Address, unsigned int Length, unsigned char *SrcAdrs)
{
	unsigned int Temp, Temp1;

	while(PMMODEbits.BUSY);					//wait till PMP is busy
	SetAddressAutoInc();					//Set address auto increment

    PMADDR = Address;						//load Address to PMADDR

	#if (defined Two16KBChips)
	  if (Address >= 0x4000)
	    asm ("bset PMADDR, #15");			//enable PMCS2
	  else
	    asm ("bset PMADDR, #14");			//enable PMCS1

	#else 
	  #if defined (Single64KBChipNoCS) 
	    Nop();
	  #else  
	   	asm ("bset PMADDR, #15");			//enable PMCS2

		#if (defined SingleMorethan32KBChip)
		  AddressHighPort |= HIGH(Address);	//load Address_high to AddressHighPORT
 	      AddressHighPort &= (AdrsPinNo | HIGH(Address));

		#elif (defined More32KBChips)
		  ChipSelectPort |= HIGH(Address);	//load Address_high to ChipSelectPORT
		  ChipSelectPort &= (CSPinNo | HIGH(Address));
	    #endif
	  #endif
	#endif

	for(Temp = 0;Temp<=Length;Temp++)
	{
		while(PMMODEbits.BUSY);				//wait till PMP is busy
		
		PMDIN1 = *SrcAdrs++;				//write the Data and increment the pointer

		#if (defined Two16KBChips)
	  	  if (PMADDR == 0x4000)
		  {	
	    	asm ("bclr PMADDR, #14");		//disable PMCS1
	    	asm ("bset PMADDR, #15");		//enable PMCS2
		  }

		#elif (defined SingleMorethan32KBChip)
		  if(PMADDR == 0x8000)
											//check for address max and if so roll over
	  		if((AddressHighPort & (AdrsPinNo^0xFFFF)) == (AdrsPinNo^0xFFFF))
			  AddressHighPort &= AdrsPinNo;
			else
		      AddressHighPort ++;			//increment the AddressHighPORT

		#elif defined (More32KBChips) 		//increment the ChipSelectPORT
		  if(PMADDR == 0x8000)
											//check for chipselect max and if so roll over
	  		if((ChipSelectPort & (CSPinNo^0xFFFF)) == (CSPinNo^0xFFFF))
			  ChipSelectPort &= CSPinNo;
			else
		      ChipSelectPort ++;			//increment the ChipSelectPORT
		#endif
	}
}// end MemBulkWrite

