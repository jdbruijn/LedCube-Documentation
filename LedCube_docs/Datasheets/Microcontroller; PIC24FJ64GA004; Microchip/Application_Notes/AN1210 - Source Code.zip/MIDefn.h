/** D E F I N I T I O N S **********************************************/

/** Selection of number of chips and its size **************************/
//Here comment all irrelevent definations keeping the required one uncommented

//#define Single64KBChipNoCS			//Using 64KB chip with CS permanently grounded.
//#define Single32KBChip				//Using 32KB chip with CS connected to PMCS2
//#define Two16KBChips					//Using two 16KB chip with CS connected to PMCS1 and PMCS2
#define SingleMorethan32KBChip			//Using more than 32KB chip with CS connected to PMCS2
//#define More32KBChips					//Using multiple 32KB chips with CS connected to output of demultplexer			

//#define Data16bit						//Using 16-bit word memory
//#define HighByteEnb					//If Active high Byte-Enable stobe is required uncomment this.


/** Selection of Address Data bus multiplexing *************************/
//Here comment all irrelevent definations keeping the required one uncommented

//#define AddressDataNoMux
//#define LowAddressDataMux
#define FullAddressDataMux

/** Delay settings *****************************************************/
//Here define the Setup time, Strobe width and hold time required
  
#define SetDataSetupWait_TCY 1			//1/2//3//4	
#define SetControlWidthWait_TCY 0		//0/1//2//3//4//5//6//7//8//9//10//11//12//13//14//15	
#define SetDataHoldWait_TCY 1			//1/2//3//4	


/** PORT used to generate higher address *******************************/
//Here define the port to be used to generate A15 onwards
 //if using more than 32KB chip 

#define AddressHighPort	LATA 			//LATA//LATB//LATC//LATD//LATE    
#define NumberofAddedAdrsLine 8			//8//7//6//5//4//3//2//1


/** PORT used to generate chip-select **********************************/
//Here define the port to be used to generate chip-select 
  //if using multiple 32KB chips
  
#define ChipSelectPort	LATA 			//LATA//LATB//LATC//LATD//LATE    
#define NumberofAddedCSLine 3			//3//2//1


//.....................................................................//



/** Do not modify this section *****************************************/

#define SetIdleDis() PMCONbits.PSIDL = 1;				//b'1';
#define SetIdleEnb() PMCONbits.PSIDL = 0;				//b'0';
#define SetAddressAutoInc()	PMMODEbits.INCM = 1;		//b'01';
#define SetAddressAutoDec() PMMODEbits.INCM = 2;		//b'10';
#define SetAddressNoAutoChange() PMMODEbits.INCM = 0;	//b'00';

/*---------------------------------------------------------------------*/

#define AdrsPinNo 0xFFFF-((1<<NumberofAddedAdrsLine)-1)
#define CSPinNo 0xFFFF-((1<<NumberofAddedCSLine)-1)

/***********************************************************************/


