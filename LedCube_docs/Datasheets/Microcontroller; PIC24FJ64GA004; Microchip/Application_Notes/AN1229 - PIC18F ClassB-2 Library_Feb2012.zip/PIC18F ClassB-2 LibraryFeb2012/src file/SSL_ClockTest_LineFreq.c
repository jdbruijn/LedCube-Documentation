
/*****************************************************************************************
* � 2008  Microchip Technology Inc.
*
* FileName:		    SSL_ClockTest_LineFreq.c
* Dependencies:     Header (.h) files if applicable, see below
* Processor:		PIC18F
* Compiler:		    MPLAB� C18 V3.21 or higher
* Company:	    	Microchip Technology, Inc.
* Version :         1.0
* Date :            10/01/08   (mm/dd/yy)
* Author:           Arpan Kumar
*
* Software License Agreement:
*
* Microchip licenses this software to you solely for use with Microchip products.
* The software is owned by Microchip and its licensors, and is protected under
* applicable copyright laws.  All rights reserved.
* SOFTWARE IS PROVIDED �AS IS.�  MICROCHIP EXPRESSLY DISCLAIMS ANY WARRANTY OF ANY
* KIND, WHETHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT.
* IN NO EVENT SHALL MICROCHIP BE LIABLE FOR ANY INCIDENTAL, SPECIAL, INDIRECT OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, HARM TO YOUR EQUIPMENT, COST
* OF PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY OR SERVICES, ANY CLAIMS BY THIRD
* PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), ANY CLAIMS FOR INDEMNITY
* OR CONTRIBUTION, OR OTHER SIMILAR COSTS.
* To the fullest extent allowed by law, Microchip and its licensors liability shall
* not exceed the amount of fees, if any, that you have paid directly to Microchip
* to use this software.
* MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE TERMS.
*
*
* REVISION HISTORY:
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* Author            Date      Comments on this revision
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* AKA                         First release of source file
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
*
**********************************************************************/
#include "..\h\SSL_ClockTest_LineFreq.h"

#include "..\h\Typedef.h"
#include <p18cxxx.h>

volatile int clockStatusFlag=0;
uReg32 timer1value=0;
void InterruptHandlerHigh (void);




  /************************************************************************************************
  * Description:
  *  The SSL_8bitsFamily_CLOCKtest_LineFreq function is used to verify the proper operation of the
  * CPU clock. The 50 Hz/60 Hz line frequency is used as the independent clock source or the reference
  * clock source. The Input capture module is used for Periodmeasurement. The 50 Hz/60 Hz line frequency
  * is fed to the Input capture pin (CCP1) of the respective device.
  *		The test performs the following major tasks:
  *         1. The CCP1CON register is configured as follows:
  *				�timer1 is selected as CCP1 time base
  *				� Interrupt is generated on every rising edge
  *
  *         2. CCP1 generates an interrupt after every 20 ms if line frequency is 50 Hz and after every 16.66ms
  *             if the line frequency is 60 Hz.Thetimer1 is configuredin such a way that the timer count does not time out within 20 ms/16.66 ms.
  *        3. The interrupt is generated on every rising edge of Line frequency. For period
  *           measurement, the interrupt is generated twice andtimer1 count is stored in the 2nd interrupt service routine.
  *
  *             For example, the following parameters are used to calculate CLK_MIN_TIME and CLK_MAX_TIME for a
  *             PIC18F device:
  *				Primary Oscillator: intosc
  *				FOSC: 8 Mhz
  *				FCY: FOSC/4: (8 * 10^6) / 4
  *				FCY: 2000000
  *      The number of counts that will be counted in the 20ms is  = 0.02 * 2000000 = 40000.
  *      With tolerance of 4%
  *	 	 #define CLK_MIN_TIME 38400
  *      #define CLK_MAX_TIME 41600
  *
  *
  * Input: None
  *
  * Return Values:
  *   	CLOCK_NO_ERROR : CPU clock is operating within its limits.
  *     CLOCK_ERROR    : CPU clock is not operating within limits
  *
  *  Note : set LINE_FREQ_50HZ to 1 for 50Hz line frequency in SSL_ClockTest_LineFreq.h file
  *         set LINE_FREQ_60HZ to 1 for 60Hz line frequency in SSL_ClockTest_LineFreq.h file
  *         give a corresponding clock at CCP1 pin of the device
  ****************************************************************************************************/
int  SSL_8bitsFamily_CLOCKtest_LineFreq()
{
unsigned int m;

for(m=0;m<10000;m++); 			// wait for sometime so that clocks get stablized

  INTCON= 0XC0;					// enable global interrupts
  TRISC=0xff;					//set RC2/CCP1 as input pin

  timer1Init_LineFreq();        //initialize timer1


  // Initialize Capture Module
   CCP1CON=0x05;

  // Clear CCP1 Interrupt Status Flag
  PIR1bits.CCP1IF = 0;

  // Enable CCP1 interrupt
  PIE1bits.CCP1IE =1;

   while( clockStatusFlag ==0);  //wait until first rising edge

    clockStatusFlag=0;

   while( clockStatusFlag ==0);   //wait until second immediate rising edge

   clockStatusFlag=0;


#if LINE_FREQ_50HZ

// check whether the count is in expected range or not?
   if ( timer1value.Word.LW < CLK_MIN_TIME_50HZ || timer1value.Word.LW > CLK_MAX_TIME_50HZ)
        return CLOCK_ERROR;
   else
        return CLOCK_NO_ERROR;
   #endif


#if LINE_FREQ_60HZ

// check whether the count is in expected range or not?
   if ( timer1value.Word.LW < CLK_MIN_TIME_60HZ || timer1value.Word.LW > CLK_MAX_TIME_60HZ)
        return CLOCK_ERROR;
   else
        return CLOCK_NO_ERROR;
   #endif


}


void timer1Init_LineFreq(void)
{
 T1CON = 0x0;      //select timer1 for input capture module
 TMR1H=0;
 TMR1L=0;
}





// High priority interrupt vector

#pragma code InterruptVectorHigh = 0x08


void InterruptVectorHigh (void)
{
  _asm
    goto InterruptHandlerHigh //jump to interrupt routine
  _endasm
}

//----------------------------------------------------------------------------
// High priority interrupt routine

#pragma code
#pragma interrupt InterruptHandlerHigh

void
InterruptHandlerHigh ()
{
extern volatile unsigned int clockTestFlag;
extern uReg32 timer0Count;
static volatile int i=0;


  if (PIR1bits.CCP1IF)		//check for TMR1 overflow
    {
      PIR1bits.CCP1IF = 0;    //clear interrupt flag
		if (i==0)
         {
		   TMR1H=0;
		   TMR1L=0;
		   T1CONbits.TMR1ON=1;
           i++;
		 }

		else
         {
           timer1value.Val[1] = TMR1H;
       	   timer1value.Val[0] = TMR1L;
		   i=0;
			 // Disable CCP1 interrupt
  			PIE1bits.CCP1IE =0;
         }

         clockStatusFlag=1;

    }

 if (PIR1bits.TMR1IF)		       //check for TMR0 overflow
    {
      T1CONbits.TMR1ON=0;
      T0CONbits.TMR0ON=0;
      PIR1bits.TMR1IF = 0;         //clear interrupt flag
   	  TMR1H = 0xff;			       // reinitialize timer1 so that it interrupts again after 1ms
	  TMR1L = 0xE0;
      clockTestFlag++;				//Set flag

      timer0Count.Val[0] = TMR0L;
      timer0Count.Val[1] = TMR0H;  //save the timer0 count

	  TMR0H=0;                     //reset timer0
	  TMR0L=0;

	  T1CONbits.TMR1ON=1;
      T0CONbits.TMR0ON=1;

	}

}

