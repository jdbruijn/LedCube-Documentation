
/*****************************************************************************************
* � 2008  Microchip Technology Inc. 
* 
* FileName:		    SSL_FlashTest_CRC16.c
* Dependencies:     Header (.h) files if applicable, see below
* Processor:		PIC18F
* Compiler:		    MPLAB� C18 V3.21 or higher
* Company:	    	Microchip Technology, Inc.
* Version :         1.0
* Date :            10/01/08   (mm/dd/yy)
* Author:           Arpan Kumar
*
* Software License Agreement:
*
* Microchip licenses this software to you solely for use with Microchip products.
* The software is owned by Microchip and its licensors, and is protected under
* applicable copyright laws.  All rights reserved.
* SOFTWARE IS PROVIDED �AS IS.�  MICROCHIP EXPRESSLY DISCLAIMS ANY WARRANTY OF ANY 
* KIND, WHETHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO, THE IMPLIED 
* WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT.
* IN NO EVENT SHALL MICROCHIP BE LIABLE FOR ANY INCIDENTAL, SPECIAL, INDIRECT OR 
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, HARM TO YOUR EQUIPMENT, COST 
* OF PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY OR SERVICES, ANY CLAIMS BY THIRD
* PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), ANY CLAIMS FOR INDEMNITY
* OR CONTRIBUTION, OR OTHER SIMILAR COSTS.
* To the fullest extent allowed by law, Microchip and its licensors liability shall
* not exceed the amount of fees, if any, that you have paid directly to Microchip 
* to use this software.
* MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE TERMS.
*
*
* REVISION HISTORY:
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* Author            Date      Comments on this revision
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* AKA                         First release of source file
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
*
**********************************************************************/
#include "..\h\SSL_Flash_CRC.h"
#include "..\h\Typedef.h"
static unsigned int *tempCRC;
  /********************************************************************
  * Description:
  *     The "SSL_8bitsFamily_Flashtest_CRC16" function Calculates the CRC of the
  *     data starting from address "FLASH_STARTADDRESS" to
  *     "FLASH_ENDADDRESS".This function returns the final CRC Value.
  *     
  *     CRC-16 is used as a divisor.
  *     
  *     CRC-16 = 1 1000 0000 0000 0101= 8005(hex).
  *
  *     The CRC Result genearated by the "SSL_8bitsFamily_Flashtest_CRC16" function can be used to do the following:
  *     1. At startup the CRC_Flag = 0x00 and the CRC checksum computed is the Reference checksum.
  *     2. This Reference Checksum is stored in the FLASH or EEPROM memory and the CRC flag is set to 0xFF. 
  *     3. The SSL_8bitsFamily_Flashtest_CRC16 can be called periodically if the CRC flag is set to 0xFF.    
  *     4. This calculated Check sum is compared with the Reference checksum.
  *     5. If the calculated and reference checksum are the same a status bit can be set in the code to indicate that
  *         the test has passed
  *           
  * Input:
  *     startAddress :  start Address from which the CRC needs to be
  *                     calculated
  *     endAddress :    This address indicates the Final address upto
  *                     which the CRC is calculated
  * Return Values:
  *  crc_Result:   Returns the final CRC result.                               
  ********************************************************************/

unsigned int SSL_8bitsFamily_Flashtest_CRC16(Word32 startAddress,Word32 endAddress,unsigned int crc_Result)
{

 unsigned char i,Buffer0,Buffer1;

 
   TBLPTR = startAddress;       // put the starting address of flash memory in pointer register

   *tempCRC=crc_Result;		
	
  for( i=0; endAddress >= startAddress;i++)
  	{
    
_asm
   TBLRDPOSTINC                 // read the flash byte
_endasm

     
   Buffer0 = TABLAT;		    //put the read data in buffer
      
_asm
   TBLRDPOSTINC                 //read the next byte
_endasm

       
  Buffer1= TABLAT;              // put the read data in another buffer

  Flash_CRC16(Buffer0,tempCRC); // call the fn to calculate the CRC
  Flash_CRC16(Buffer1,tempCRC);

  startAddress += 2;       	    // increment the address

 	}

 crc_Result= *tempCRC;		    //save the final crc result

 return crc_Result;

}


  /*********************************************************************
  * Description:
  *     Calculates the CRC checkksum for a byte of data.
  * Input:
  *     Data :     Data for which the CRC needs to be calculated
  *     tempCRC :  This pointer holds the CRC result for the Data that
  *                is passed.
  * Return Values:
  *     : None                                                          
  *********************************************************************/

void Flash_CRC16(char Data,  unsigned int *tempCRC) 
{
    int i ;

    for ( i = 8 ; i > 0 ; i-- )  {
        if ( (Data ^ (*tempCRC)) & 0x8000 ) {
           (*tempCRC) = ((*tempCRC)<< 1) ^ FLASH_GEN_POLY ;
        }
        else {
            (*tempCRC) <<= 1 ;
        }
        Data <<= 1 ;
    }

}
