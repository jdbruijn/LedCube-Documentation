
/*****************************************************************************************
* � 2008  Microchip Technology Inc. 
* 
* FileName:		    SSL_MarchBRamTest.c
* Dependencies:     Header (.h) files if applicable, see below
* Processor:		PIC18F
* Compiler:		    MPLAB� C18 V3.21 or higher
* Company:	    	Microchip Technology, Inc.
* Version :         1.0
* Date :            10/01/08   (mm/dd/yy)
* Author:           Arpan Kumar
*
* Software License Agreement:
*
* Microchip licenses this software to you solely for use with Microchip products.
* The software is owned by Microchip and its licensors, and is protected under
* applicable copyright laws.  All rights reserved.
* SOFTWARE IS PROVIDED �AS IS.�  MICROCHIP EXPRESSLY DISCLAIMS ANY WARRANTY OF ANY 
* KIND, WHETHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO, THE IMPLIED 
* WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT.
* IN NO EVENT SHALL MICROCHIP BE LIABLE FOR ANY INCIDENTAL, SPECIAL, INDIRECT OR 
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, HARM TO YOUR EQUIPMENT, COST 
* OF PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY OR SERVICES, ANY CLAIMS BY THIRD
* PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), ANY CLAIMS FOR INDEMNITY
* OR CONTRIBUTION, OR OTHER SIMILAR COSTS.
* To the fullest extent allowed by law, Microchip and its licensors liability shall
* not exceed the amount of fees, if any, that you have paid directly to Microchip 
* to use this software.
* MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE TERMS.
*
*
* REVISION HISTORY:
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* Author            Date      Comments on this revision
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* AKA                         First release of source file
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
*
**********************************************************************/

#include "..\h\SSL_MarchB.h"

  /**********************************************************************
  * Description:
  *     This function implements the March B test. It is a complete and non redundant test 
  *     capable of detecting stuck-at faults.linked coupling Idempotent faults or Inversion
  *     Coupling faults. This test is of complexity 17n( Where n is the number of bits). 
  *     This test uses byte( 8-bit) accesses. The address must be properly aligned to the 
  *     data type.This is a 
  *     destructive test i.e, the memory contents is not preserved.Hence this test is meant
  *     to be run at system startup, before the memory and the run time library is initialized.
  *     The memory will be cleared (=0) when "SSL_8bitsFamily_RAMtest_MarchB" test returns
  *     
  * Input:
  *     ramStartAddress :  start Address from which the March B test
  *                        is to be performed.
  *     ramSize :          Number of bytes for which the test is to be
  *                        performed.
  * Return Values:
  *     MARCHB_TEST_FAIL :  return value = 0
  *     MARCHB_TEST_PASS :  return value = 1
  *                                                 
  **********************************************************************/


 static int Rd0Wr1Rd1Wr0Rd0Wr1(volatile char * );
 static int Rd1Wr0Wr1(volatile char * );
 static int Rd1Wr0Wr1Wr0(volatile char *);
 static int Rd0Wr1Wr0(volatile char *);

 int  SSL_8bitsFamily_RAMtest_MarchB(char * ramStartAddress,int ramSize)
	{
    int testResult=0; 
 	char  * ptr;   	

 
  
	// erase all sram
   	    for(ptr=ramStartAddress ; ptr< ramStartAddress + ramSize ; ptr++)
              *ptr=0x00;                                                     //write 0



   	    for(ptr=ramStartAddress; ptr<ramStartAddress +ramSize; ptr++)
         {

             testResult = Rd0Wr1Rd1Wr0Rd0Wr1((volatile char *)ptr); 

 			 if ( !testResult)
             return MARCHB_TEST_FAIL;

         }


   
        for(ptr=ramStartAddress; ptr<ramStartAddress+ramSize; ptr++)
          {  
      
             testResult = Rd1Wr0Wr1((volatile char *)ptr);

             if ( !testResult)
             return MARCHB_TEST_FAIL;
          } 


        for (ptr=(ramStartAddress+(ramSize-1));ptr>=(ramStartAddress);ptr--) 
         {  

             testResult =Rd1Wr0Wr1Wr0((volatile char *)ptr);

             if ( !testResult)
             return MARCHB_TEST_FAIL;
         }
    
   
        for (ptr=(ramStartAddress+ramSize-1);ptr>=(ramStartAddress);ptr--) 
          {  

             testResult =Rd0Wr1Wr0((volatile char *)ptr);  

			 if ( !testResult)
             return MARCHB_TEST_FAIL;
          }
  return testResult;
}

  /**************************************************************
  * Description:
  *     This function does the following :
  *     
  *     1> Tests bitwise if bit is zero and replace with one .
  *     
  *     2> Tests bitwise if bit is one and replace with zero.
  *     
  *     3> Tests bitwise if bit is zero and replace with one.
  * Input:
  *     ptr :  Address location of the the bits to be tested.
  * Return Values:
  *     MARCHB_TEST_FAIL :  return value = 0.
  *     MARCHB_TEST_PASS :  return value = 1
  *                                                            
  **************************************************************/

static int Rd0Wr1Rd1Wr0Rd0Wr1(volatile char * ptr)
{

 	int  tempValue;  
    int loopCounter;



           for (loopCounter=0;loopCounter<MARCHB_BIT_WIDTH;loopCounter++)
              {
                
 	   

             	tempValue =  (((*ptr) >> loopCounter) & 0x01);   //Read 0
                
                if( tempValue != 0x00)
                	{ 
             	   		return MARCHB_TEST_FAIL;
               	    }

               
                tempValue = *ptr | (1<<loopCounter);             // write 1
                *ptr= tempValue;                              

                tempValue =(((*ptr)>>loopCounter) & 0x01);       // read 1 

 		        if (tempValue!= 0x01) 
      			   {
            			return MARCHB_TEST_FAIL;
      			   }

				 tempValue =  *ptr  & ~(1<<loopCounter);         // write 0
                 *ptr= tempValue;                                 
        
                 tempValue =(((*ptr)>>loopCounter) & 0x01);      // read 0 

        		 if (tempValue!= 0x00) 
        		   {
                        return MARCHB_TEST_FAIL;
                   } 

                *ptr=(*ptr | (1<<loopCounter));                  // write 1

             } 
	return MARCHB_TEST_PASS; 

}

  /******************************************************************
  * Description:
  *     This function does the following:
  *     
  *     1> Tests bitwise if a bit is one and replace it with Zero.
  *     
  *     2> Write Zero Bitwise.
  * Input:
  *     ptr :  Address location of the the bits to be tested.
  * Return Values:
  *     MARCHB_TEST_FAIL :  return value = 0
  *     MARCHB_TEST_PASS :  return value = 1
  *                                                                
  ******************************************************************/
static int Rd1Wr0Wr1(volatile char * ptr)

{
	int  tempValue;  
    int loopCounter;

			 for (loopCounter=0;loopCounter<MARCHB_BIT_WIDTH;loopCounter++)
              {
      
                 tempValue =(((*ptr)>>loopCounter) & 0x01);       // read 1 
                 if ( tempValue!= 0x01) 
                    {
                        return MARCHB_TEST_FAIL;
                    }
    
                tempValue =  *ptr  & ~(1<<loopCounter);
                *ptr=  tempValue;                                // write 0
          
                *ptr=(*ptr | (1<<loopCounter));                  // write 1
      
              } 
	return MARCHB_TEST_PASS; 
}

  /******************************************************************
  * Description:
  *     This function does the following:
  *     
  *     1> Tests bitwise if a bit is one and replace it with Zero.
  *     
  *     2> write one Bitwise.
  *     
  *     3> write Zero Bitwise.
  * Input:
  *     ptr :  Address location of the the bits to be tested.
  * Return Values:
  *     MARCHB_TEST_FAIL :  return value = 0
  *     MARCHB_TEST_PASS :  return value = 1
  *                                                                
  ******************************************************************/
 
static int Rd1Wr0Wr1Wr0(volatile char * ptr)

{

	int  tempValue;  
    int loopCounter;

			for (loopCounter=MARCHB_BIT_WIDTH-1;loopCounter>=0;loopCounter--)
              {
         
                  tempValue =(((*ptr)>>loopCounter) & 0x01);     // read 1 
                  if (tempValue!= 0x01) 
                    {
                        return MARCHB_TEST_FAIL;
                   }
     
                  tempValue =  *ptr & ~(1<<loopCounter);
                  *ptr= tempValue;                               // write 0
          
                  *ptr=(*ptr | (1<<loopCounter));                // write 1
         
                  tempValue =  *ptr & ~(1<<loopCounter);
                  *ptr= tempValue;                               // write 0
          
              }
    return MARCHB_TEST_PASS; 
}
  /******************************************************************
  * Description:
  *     This function does the following:
  *     
  *     1> Tests bitwise if a bit is zero and replace it with one.
  *     
  *     2> Write Zero.
  * Input:
  *     ptr :  Address location of the the bits to be tested.
  * Return Values:
  *     MARCHB_TEST_FAIL :  return value = 0
  *     MARCHB_TEST_PASS :  return value = 1
  *                                                                
  ******************************************************************/


static int Rd0Wr1Wr0(volatile char * ptr)
{

	int  tempValue;  
    int loopCounter;

             for (loopCounter=MARCHB_BIT_WIDTH-1;loopCounter>=0;loopCounter--)
               {
         
                  tempValue =(((*ptr)>>loopCounter) & 0x01);     // read 0 
                  if (tempValue!= 0x00) 
                     {
                         return MARCHB_TEST_FAIL;
                     } 
                  
                  *ptr=(*ptr | (1<<loopCounter));                // write 1
          
                  tempValue =  *ptr & ~(1<<loopCounter);
                  *ptr= tempValue;                               // write 0
         
               }
	return MARCHB_TEST_PASS; 
}
