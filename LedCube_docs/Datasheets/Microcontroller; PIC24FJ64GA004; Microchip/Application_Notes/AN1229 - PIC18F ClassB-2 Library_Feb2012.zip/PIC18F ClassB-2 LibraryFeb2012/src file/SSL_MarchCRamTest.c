
/*****************************************************************************************
* � 2008  Microchip Technology Inc. 
* 
* FileName:		    SSL_MarchRamTest.c
* Dependencies:     Header (.h) files if applicable, see below
* Processor:		PIC18F
* Compiler:		    MPLAB� C18 V3.21 or higher
* Company:	    	Microchip Technology, Inc.
* Version :         1.0
* Date :            10/01/08   (mm/dd/yy)
* Author:           Arpan Kumar
*
* Software License Agreement:
*
* Microchip licenses this software to you solely for use with Microchip products.
* The software is owned by Microchip and its licensors, and is protected under
* applicable copyright laws.  All rights reserved.
* SOFTWARE IS PROVIDED �AS IS.�  MICROCHIP EXPRESSLY DISCLAIMS ANY WARRANTY OF ANY 
* KIND, WHETHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO, THE IMPLIED 
* WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT.
* IN NO EVENT SHALL MICROCHIP BE LIABLE FOR ANY INCIDENTAL, SPECIAL, INDIRECT OR 
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, HARM TO YOUR EQUIPMENT, COST 
* OF PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY OR SERVICES, ANY CLAIMS BY THIRD
* PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), ANY CLAIMS FOR INDEMNITY
* OR CONTRIBUTION, OR OTHER SIMILAR COSTS.
* To the fullest extent allowed by law, Microchip and its licensors liability shall
* not exceed the amount of fees, if any, that you have paid directly to Microchip 
* to use this software.
* MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE TERMS.
*
*
* REVISION HISTORY:
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* Author            Date      Comments on this revision
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* AKA                         First release of source file
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
*
**********************************************************************/
#include "..\h\SSL_MarchC.h"

static int ReadZeroWriteOne(volatile char *);
static int ReadOneWriteZero(volatile char *);
static int ReadZero(volatile char *);
int  SSL_8bitsFamily_RAM_MarchC(char * ramStartAddress,int ramSize, int minus);


  /**********************************************************************
  * Description:
  *     This function implements the March C test .The test is suited
  *     to find all stuck-at faults ,transition faults and coupling
  *     faults.The complexity of this test is 11n ( n is the number
  *     of bits). This test uses byte( 8-bit) accesses.
  *     This is a destructive
  *     test i.e, the memory contents is not preserved.Hence this
  *     test is meant to be run at system startup, before the memory
  *     and the run time library is initialized. The memory will be
  *     cleared (=0) when "SSL_8bitsFamily_RAMtest_MarchC" test
  *     returns.
  *     
  *     
  * Input:
  *     ramStartAddress :  Address were March C algorithm starts.<p />
  *     ramSize :          Number of bytes for which the test is to be
  *                        performed.
  * Return Values:
  *     MARCHC_RAM_TEST_FAIL : return value = 0
  *     MARCHC_RAM_TEST_PASS : return value = 1
  *                                                    
  **********************************************************************/

int  SSL_8bitsFamily_RAMtest_MarchC(char * ramStartAddress,int ramSize)
{
    SSL_8bitsFamily_RAM_MarchC(ramStartAddress, ramSize, 0);
}

  /**********************************************************************
  * Description:
  *     This function implements the March C minus test .The test is suited
  *     to find all stuck-at faults ,transition faults and coupling
  *     faults.The complexity of this test is 10n ( n is the number
  *     of bits). This test uses byte( 8-bit) accesses.
  *     This is a destructive
  *     test i.e, the memory contents is not preserved.Hence this
  *     test is meant to be run at system startup, before the memory
  *     and the run time library is initialized. The memory will be
  *     cleared (=0) when "SSL_8bitsFamily_RAMtest_MarchC" test
  *     returns.
  *     
  *     
  * Input:
  *     ramStartAddress :  Address were March C algorithm starts.<p />
  *     ramSize :          Number of bytes for which the test is to be
  *                        performed.
  * Return Values:
  *     MARCHC_RAM_TEST_FAIL : return value = 0
  *     MARCHC_RAM_TEST_PASS : return value = 1
  *                                                    
  **********************************************************************/

int  SSL_8bitsFamily_RAMtest_MarchC_Minus(char * ramStartAddress,int ramSize)
{
    SSL_8bitsFamily_RAM_MarchC(ramStartAddress, ramSize, 1);
}


  /**********************************************************************
  * Description:
  *     This function implements the March C test .The test is suited
  *     to find all stuck-at faults ,transition faults and coupling
  *     faults.The complexity of this test is 11n ( n is the number
  *     of bits). This test uses byte( 8-bit) accesses.
  *     This is a destructive
  *     test i.e, the memory contents is not preserved.Hence this
  *     test is meant to be run at system startup, before the memory
  *     and the run time library is initialized. The memory will be
  *     cleared (=0) when "SSL_8bitsFamily_RAMtest_MarchC" test
  *     returns.
  *     
  *     
  * Input:
  *     ramStartAddress :  Address were March C algorithm starts.<p />
  *     ramSize :          Number of bytes for which the test is to be
  *                        performed.
  *     minus :            MarchC minus test if 1.
  * Return Values:
  *     MARCHC_RAM_TEST_FAIL : return value = 0
  *     MARCHC_RAM_TEST_PASS : return value = 1
  *                                                    
  **********************************************************************/

int  SSL_8bitsFamily_RAM_MarchC(char * ramStartAddress,int ramSize, int minus)
	{
    int testResult; 
 	char  * ptr;   	
  
	// erase all sram
   	    for(ptr=ramStartAddress ; ptr< ramStartAddress + ramSize ; ptr++)
           *ptr=0x00;                                         //write 0
        
    
   //Test Bitwise if 0 and replace it with 1 starting from lower Addresses
   	    for(ptr=ramStartAddress; ptr<ramStartAddress + ramSize; ptr++)
         {

          testResult =  ReadZeroWriteOne((volatile char *)ptr);

           if ( !testResult)
             return MARCHC_RAM_TEST_FAIL;
        
       	 } 

  //Test Bitwise if 1 and replace it with 0 starting from lower Addresses
        for(ptr=ramStartAddress; ptr<ramStartAddress + ramSize; ptr++)
         {
            
           testResult =  ReadOneWriteZero((volatile char *)ptr);

           if ( !testResult)
             return MARCHC_RAM_TEST_FAIL;
      
         }                  

 //Test if all bits are zeros starting from lower Addresses
        if(minus == 0)
        {
 
            for(ptr=ramStartAddress; ptr<(ramStartAddress + ramSize); ptr++)
             {
            
                testResult =  ReadZero((volatile char *)ptr);

              if ( !testResult)
                 return MARCHC_RAM_TEST_FAIL;
             }
        }

//Test Bitwise if 0 and replace it with 1 starting from higher Addresses
        for (ptr=ramStartAddress + (ramSize-1);ptr>=(ramStartAddress);ptr--) 
         {  

        	  testResult =  ReadZeroWriteOne((volatile char *)ptr);

         	 if ( !testResult)
             return MARCHC_RAM_TEST_FAIL;

         }
//Test Bitwise if 1 and replace it with 0 starting from higher Addresses
        for (ptr=(ramStartAddress + (ramSize-1));ptr>=(ramStartAddress);ptr--) 
         {  
            testResult =  ReadOneWriteZero((volatile char *)ptr);

			 if ( !testResult)
             return MARCHC_RAM_TEST_FAIL;
         }

//Test if all bits are zeros starting from higher Addresses
        for (ptr=(ramStartAddress + (ramSize-1));ptr>=(ramStartAddress);ptr--) 
         {  
            testResult =  ReadZero((volatile char *)ptr);

			 if ( !testResult)
             return MARCHC_RAM_TEST_FAIL;
         }

    return testResult;

   } // End of function



  /*******************************************************************
  * Description:
  *     This function tests bitwise if a bit is zero and replaces it
  *     with one.
  * Input:
  *     ptr :  Address location of the the bits to be tested
  * Return Values:
  *     MARCHC_RAM_TEST_FAIL :  return value = 0
  *     MARCHC_RAM_TEST_PASS :  return value = 1
  *                                                                 
  *******************************************************************/


static int ReadZeroWriteOne(volatile char * ptr)
    {
	int  tempValue;  
    int loopCounter;

            for (loopCounter=MARCHC_BIT_WIDTH-1;loopCounter>=0;loopCounter--)
              {
                     
				  tempValue =(((*ptr)>>loopCounter) & 0x01);  // read 0 
                  if (tempValue!= 0x00) 
                     {
                         return MARCHC_RAM_TEST_FAIL;
                     } 
                  
                  *ptr=(*ptr | (1<<loopCounter));             // write 1
          
              }

    return MARCHC_RAM_TEST_PASS;  
  
	}

  /******************************************************************
  * Description:
  *     This function tests bitwise if a bit is one and replaces it
  *     with zero.
  * Input:
  *     ptr :  Address location of the the bits to be tested
  * Return Values:
  *     MARCHC_RAM_TEST_FAIL :  return value = 0
  *     MARCHC_RAM_TEST_PASS :  return value = 1
  *                                                                
  ******************************************************************/


static int ReadOneWriteZero(volatile char * ptr ) 

    {

	int  tempValue;  
    int loopCounter;


          for (loopCounter=0;loopCounter<MARCHC_BIT_WIDTH ;loopCounter++)
              {

                  tempValue =(((*ptr)>>loopCounter) & 0x01);     // read 1 

		          if (tempValue!= 0x01) 
     			   {
            			return MARCHC_RAM_TEST_FAIL;
     			   }


 		 	      tempValue =  *ptr  & ~(1<<loopCounter);       // write 0
                  *ptr= tempValue;     

                }
     return MARCHC_RAM_TEST_PASS; 
    }

  /***********************************************************
  * Description:
  *     This function tests bitwise if all bits are zeros .
  * Input:
  *     ptr :  Address location of the the bits to be tested
  * Return Values:
  *     MARCHC_RAM_TEST_FAIL :  \return value = 0<p />
  *     MARCHC_RAM_TEST_PASS :  \return value = 1
  *                                                         
  ***********************************************************/
static int ReadZero(volatile char * ptr ) 
     {

	int  tempValue;  
    int loopCounter;

            for (loopCounter=0;loopCounter<MARCHC_BIT_WIDTH ;loopCounter++)
              {

                 tempValue =(((*ptr)>>loopCounter) & 0x01);    // read 0 

        		 if (tempValue!= 0x00) 
        		   {
                        return MARCHC_RAM_TEST_FAIL;
                   }

               }
    return MARCHC_RAM_TEST_PASS; 
     }

