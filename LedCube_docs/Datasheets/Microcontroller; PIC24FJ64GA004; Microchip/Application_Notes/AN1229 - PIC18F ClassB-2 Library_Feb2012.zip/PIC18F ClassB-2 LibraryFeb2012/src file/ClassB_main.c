
/*****************************************************************************************
* � 2008  Microchip Technology Inc. 
* 
* FileName:		    ClassB_main.c
* Dependencies:     Header (.h) files if applicable, see below
* Processor:		PIC18F
* Compiler:		    MPLAB� C18 V3.21 or higher
* Company:	    	Microchip Technology, Inc.
* Version :         1.0
* Date :            10/01/08   (mm/dd/yy)
* Author:           Arpan Kumar
*
* Software License Agreement:
*
* Microchip licenses this software to you solely for use with Microchip products.
* The software is owned by Microchip and its licensors, and is protected under
* applicable copyright laws.  All rights reserved.
* SOFTWARE IS PROVIDED �AS IS.�  MICROCHIP EXPRESSLY DISCLAIMS ANY WARRANTY OF ANY 
* KIND, WHETHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO, THE IMPLIED 
* WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT.
* IN NO EVENT SHALL MICROCHIP BE LIABLE FOR ANY INCIDENTAL, SPECIAL, INDIRECT OR 
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, HARM TO YOUR EQUIPMENT, COST 
* OF PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY OR SERVICES, ANY CLAIMS BY THIRD
* PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), ANY CLAIMS FOR INDEMNITY
* OR CONTRIBUTION, OR OTHER SIMILAR COSTS.
* To the fullest extent allowed by law, Microchip and its licensors liability shall
* not exceed the amount of fees, if any, that you have paid directly to Microchip 
* to use this software.
* MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE TERMS.
*
*
* REVISION HISTORY:
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* Author            Date      Comments on this revision
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* AKA                         First release of source file
* MVL			13/04/2010
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
*
**********************************************************************/

#include <p18cxxx.h>

//#include ".\h\SSL_MarchcStackTest.h"
#include ".\h\SSL_PcTest.h"
#include ".\h\SSL_MarchC.h"
#include ".\h\SSL_MarchB.h"
#include ".\h\SSL_Flash_CRC.h"
//#include ".\h\SSL_EEPROM_CRC.h"        //comment the line for the devices not having EEPROM
#include ".\h\SSL_ClockTest.h"
#include ".\h\SSL_ClockTest_LineFreq.h"
#include ".\h\SSL_MarchC_RamAndStackTest.h"


/* comment the lines for the devices which configuration has to be set in configuration setting option in MPLAB IDE */

#pragma config  WDT =OFF 				   // watchdog timer off// WDT for 4520
#pragma config  OSC = IRCIO7             //INTRC-OSC2 as RA6, OSC1 as RA7// OSC=INTIO67 for 18F4520 // OSC= IRCIO7 for 18F4580                  
#pragma config  XINST = OFF          	   // extended inst set disabled
#pragma config	LVP = OFF				   // Disable LVP programing
            


unsigned int testResult=0;

struct  ClassB_Test_Flags 
{

unsigned int  cpuRegister_TestResult: 1 ;
unsigned int  programCounter_TestResult: 1;
unsigned int  checkerboardRam_TestResult: 1;
unsigned int  marchCRam_TestResult: 1;
unsigned int  marchC_minus_Ram_TestResult: 1;
unsigned int  marchBRam_TestResult:1;
unsigned int  flash_TestResult: 1;          //does not get affected directly, user has to see the checksum values obtained at different times and then set the bit if both r same
unsigned int  eeprom_TestResult: 1;			//does not get affected directly, user has to see the checksum values obtained at different times and then set the bit if both r same 
unsigned int  clock_TestResult: 1;			// 32KHz crystal has to be used as TIMER1 OSC to get the test result correctly
unsigned int  line_clock_TestResult: 1;     // connect a 50/60Hz input to CCP1 pin to get the test result correctly
unsigned int  marchCRamStack_TestResult: 1;

} testFlag={0,0,0,0,0,0,0,0,0,0,0};         // initialize the bits as 0

    
    
 void main(void)
{


void SSL_8bitsFamily_CPU_RegisterTest(void);
void SSL_8bitsFamily_Ram_CB_test(void);
 
 
 
    /* Variables for Flash Test*/
    UWord32 startAddress;
    UWord32 endAddress;
    unsigned int flash_crc_Result=0;
    unsigned int init_CrcValue=0x0345;           //user can change it 

  
   /* Variables for EEPROM Test */

    uReg32 startAddress2;
    uReg32 endAddress2;
    unsigned int  eeprom_crc_Result;
    unsigned int init_CrcValue2=0x0345;			 //user can change it 

  

    /*Variables for RAM Test */
    char * ramStartAddress;
    unsigned int ramSize;


/* setting the internal clock to 8 Mhz for p18f46K20, 
   comment the line for the devices which configuration has to be set in configuration setting option in MPLAB IDE */
	
	OSCCON = 0b01100000;      

        
  
// To invoke the "SSL_8bitsFamily_RAM_STACKtest_MarchC" function include the file "SSL_MarchC_RamAndStackTest.c" 
// and comment the "SSL_8bitsFamily_RAMtest_MarchC" function and remove the "SSL_MarchCRamTest.c"
// from the workspace.

 /****************************/
 /* MarchC RAM and Stack Test*/
 /****************************/
    ramStartAddress = ( char *) MARCHC_RAMTEST_START_ADDRESS ;

    ramSize = MARCHC_RAMTEST_SIZE;

    if (SSL_8bitsFamily_RAM_STACKtest_MarchC(ramStartAddress,ramSize )) 
        testFlag.marchCRamStack_TestResult = 1;
    else
        testFlag.marchCRamStack_TestResult = 0;



/**********************************************************************************/
/*                                  CPU REGISTER TEST                             */                              
/**********************************************************************************/
   SSL_8bitsFamily_CPU_RegisterTest();   
    if(WREG)											//(WREG==0x13) 	MVL 13/04/2010
         testFlag.cpuRegister_TestResult = 0;			//1 			MVL 13/04/2010
    else 
         testFlag.cpuRegister_TestResult = 1; 			//0				MVL 13/04/2010

/**********************************************************************************/
/*                                  PROGRAM COUNTER TEST                          */                              
/**********************************************************************************/

    if (SSL_8bitsFamily_PCtest()) 
         testFlag.programCounter_TestResult = 1;
    else 
         testFlag.programCounter_TestResult = 0; 

/**********************************************************************************/
/*                                  RAM TEST                                      */                              
/**********************************************************************************/
   
   /*************************/
   /* Checker Board RAM test*/
   /*************************/
     
     SSL_8bitsFamily_Ram_CB_test();
    if 	(WREG) 											//(WREG==0x13) 	MVL 13/04/2010
        testFlag.checkerboardRam_TestResult = 0;		//1				MVL 13/04/2010
    else
        testFlag.checkerboardRam_TestResult = 1;		//0				MVL 13/04/2010





   /*************************/
   /*    MarchC RAM test    */
   /*************************/
  
     ramStartAddress = ( char *) MARCHC_RAM_START_ADDRESS ;
    
     ramSize = MARCHC_RAM_SIZE;
  
     if (SSL_8bitsFamily_RAMtest_MarchC(ramStartAddress,ramSize )) 
        testFlag.marchCRam_TestResult = 1;
     else
        testFlag.marchCRam_TestResult = 0;

   /**************************/
   /* MarchC Minus RAM test  */
   /**************************/

     ramStartAddress = ( char *) MARCHC_RAM_START_ADDRESS ;
     
     ramSize = MARCHC_RAM_SIZE;
  
     if (SSL_8bitsFamily_RAMtest_MarchC_Minus(ramStartAddress,ramSize )) 
        testFlag.marchC_minus_Ram_TestResult = 1;
     else
      testFlag.marchC_minus_Ram_TestResult = 0;  
        
        
  /****************************/
  /*    March B Ram Test      */
  /****************************/

      ramStartAddress = (char *) MARCHB_RAM_START_ADDRESS ;

      ramSize = MARCHB_RAM_SIZE;

      if (SSL_8bitsFamily_RAMtest_MarchB(ramStartAddress,ramSize )) 
        testFlag.marchBRam_TestResult = 1;
      else
         testFlag.marchBRam_TestResult = 0;

  
/**********************************************************************************/
/*                                  FLASH TEST                                    */                              
/**********************************************************************************/
 // This function can be called at startup to generate the Reference checksum.The 
 // same function can be called periodically and the generated checksum can be 
 // compared with the reference checksum. If both are the same the "flash_TestResult"
 // status bit can be set. 
    startAddress= FLASH_STARTADDRESS;

    endAddress =  FLASH_ENDADDRESS;

    flash_crc_Result = SSL_8bitsFamily_Flashtest_CRC16(startAddress,endAddress,init_CrcValue);



//comment the below written EEPROM test call for the devices not having EEPROM
    
/**********************************************************************************/
/*                                  EEPROM TEST                                   */                              
/**********************************************************************************/
 // This function can be called at startup to generate the Reference checksum.The 
 // same function can be called periodically and the generated checksum can be 
 // compared with the reference checksum. If both are the same the "eeprom_TestResult"
 // status bit can be set

//    startAddress2.Val32= EEPROM_STARTADDRESS;
//
//    endAddress2.Val32 =  EEPROM_ENDADDRESS;
//
//    eeprom_crc_Result = SSL_8bitsFamily_EEPROMtest_CRC16(startAddress2,endAddress2,init_CrcValue2);   



     
        


/**********************************************************************************/
/*        CLOCK  TEST WITH SECONDARY OSCILLATOR AS REFERENCE CLOCK                */                             
/**********************************************************************************/

   	   if (SSL_8bitsFamily_CLOCKtest()) 
          testFlag.clock_TestResult=1;
       else 
          testFlag.clock_TestResult=0; 
/**********************************************************************************/
/*      CLOCK  TEST WITH 50HZ/60Hz LINE FREQUENCY AS REFERENCE CLOCK              */                             
/**********************************************************************************/
	   
        if (SSL_8bitsFamily_CLOCKtest_LineFreq()) 
          testFlag.line_clock_TestResult=1;
        else 
          testFlag.line_clock_TestResult=0; 

            
      while(1);
      
}
 


