
/*****************************************************************************************
* � 2008  Microchip Technology Inc.
*
* FileName:		    SSL_MarchC_StackTest.c
* Dependencies:     Header (.h) files if applicable, see below
* Processor:		PIC18F
* Compiler:		    MPLAB� C18 V3.21 or higher
* Company:	    	Microchip Technology, Inc.
* Version :         1.0
* Date :            10/01/08   (mm/dd/yy)
* Author:           Arpan Kumar
*
* Software License Agreement:
*
* Microchip licenses this software to you solely for use with Microchip products.
* The software is owned by Microchip and its licensors, and is protected under
* applicable copyright laws.  All rights reserved.
* SOFTWARE IS PROVIDED �AS IS.�  MICROCHIP EXPRESSLY DISCLAIMS ANY WARRANTY OF ANY
* KIND, WHETHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT.
* IN NO EVENT SHALL MICROCHIP BE LIABLE FOR ANY INCIDENTAL, SPECIAL, INDIRECT OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, HARM TO YOUR EQUIPMENT, COST
* OF PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY OR SERVICES, ANY CLAIMS BY THIRD
* PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), ANY CLAIMS FOR INDEMNITY
* OR CONTRIBUTION, OR OTHER SIMILAR COSTS.
* To the fullest extent allowed by law, Microchip and its licensors liability shall
* not exceed the amount of fees, if any, that you have paid directly to Microchip
* to use this software.
* MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE TERMS.
*
*
* REVISION HISTORY:
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* Author            Date            Comments on this revision
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* AK                                First release of source file
* AK                13th May 2010   Added Software stack test
* AK				14th Dec 2010	Modified hardware stack test
* AK				22nd Dec 2010	Modified software stack test
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
*
**********************************************************************/
#include "..\h\SSL_MarchC_RamAndStackTest.h"
#include <p18cxxx.h>

int ssl_RamTestResult;
int ssl_HardwareStackTestResult;

static int ReadZeroWriteOne(void);
static int ReadOneWriteZero(void);
static int ReadZero(void);
static int MarchCSoftwareStackTest(void); 

char  * S_ptr;
    
int  TempValue_sw_stack;
unsigned char  LoopCounter_sw_stack_unsigned; // used for s/w stack testing to avoid the usage of FSR1 register in disassemble code
char  LoopCounter_sw_stack,LoopCounter_sw_stack_temp;
char  * ptr_sw_stack;
char arr[3];

/* variables for hardware stack testing */
int  TempValue;
int LoopCounter;
int STKPTR_Var;
unsigned int FSR1_temp;
unsigned char Avoid_FSR1_use;

  /*************************************************************************
  * Description:
  *     Function Name: SSL_16bitsFamily_RAM_STACKtest_MarchC
  *     
  *     This function implements the March C test on Ram and Stack.This test is suited to
  *     find all stuck-at faults ,transition faults and coupling faults. The complexity of 
  *     this test is 11n( n is the number of bits).This test uses Word(8-bit)accesses. 
  *     This function also tests the stack (Hardware and software stack both) area by
  *     copying the stack contents into an already tested Ram area. It then performs March C
  *     test on the stack area. After the stack is tested it restores the contents of the stack.
  *     This is a destructive test for RAM i.e, the memory contents of RAM is not preserved.Hence this test is
  *     meant to be run at system startup, before the memory and the run time library is 
  *     initialized. The memory(RAM)will be cleared (=0) when "SSL_8bitsFamily_RAM_STACKtest_MarchC"
  *     test returns
  *      NOTE:
  *      1: Compiler uses some starting locations of RAM to save Global variables, that area should 
  *         be avoided in testing
  *      2: Hardware Stack or Software Stack or RAM, if any of these does not work for given locations,
  *         then the test fails
  *
  * Input:
  *     ramStartAddress :  Address were March C algorithm starts.
  *     ramSize :          Number of bytes for which the test is to be
  *                        performed.
  * Return Values:
  *     MARCHC_RAM_STACK_TEST_FAIL :  return value = 0
  *     MARCHC_RAM_STACK_TEST_PASS :  return value = 1                      
  *************************************************************************/
  

int   SSL_8bitsFamily_RAM_STACKtest_MarchC(char * ramStartAddress,unsigned int ramSize)
	{


  	// erase all sram
   	    for(ptr_sw_stack=ramStartAddress ; ptr_sw_stack < (ramStartAddress + ramSize) ; ptr_sw_stack++)
           *ptr_sw_stack=0x0000;                                         //write 0
         
    
   //Test Bitwise if 0 and replace it with 1 starting from lower Addresses
   	    for(ptr_sw_stack=ramStartAddress; ptr_sw_stack<(ramStartAddress + ramSize); ptr_sw_stack++)
         {

          ssl_RamTestResult =  ReadZeroWriteOne();

           if ( !ssl_RamTestResult)
             return MARCHC_RAM_STACK_TEST_FAIL;
        
       	 } 

  //Test Bitwise if 1 and replace it with 0 starting from lower Addresses
        for(ptr_sw_stack=ramStartAddress; ptr_sw_stack<(ramStartAddress + ramSize); ptr_sw_stack++)
         {
            
           ssl_RamTestResult =  ReadOneWriteZero();

           if ( !ssl_RamTestResult)
             return MARCHC_RAM_STACK_TEST_FAIL;
      
         }                  

 //Test if all bits are zeros starting from lower Addresses
        for(ptr_sw_stack=ramStartAddress; ptr_sw_stack<(ramStartAddress + ramSize); ptr_sw_stack++)
         {
            
            ssl_RamTestResult =  ReadZero();

          if ( !ssl_RamTestResult)
             return MARCHC_RAM_STACK_TEST_FAIL;
         }

//Test Bitwise if 0 and replace it with 1 starting from higher Addresses
        for (ptr_sw_stack=ramStartAddress + (ramSize-1);ptr_sw_stack>=(ramStartAddress);ptr_sw_stack--) 
         {  

        	  ssl_RamTestResult =  ReadZeroWriteOne();

         	 if ( !ssl_RamTestResult)
             return MARCHC_RAM_STACK_TEST_FAIL;

         }
//Test Bitwise if 1 and replace it with 0 starting from higher Addresses
        for (ptr_sw_stack=(ramStartAddress + (ramSize-1));ptr_sw_stack>=(ramStartAddress);ptr_sw_stack--) 
         {  
            ssl_RamTestResult =  ReadOneWriteZero();

			 if ( !ssl_RamTestResult)
             return MARCHC_RAM_STACK_TEST_FAIL;
         }

//Test if all bits are zeros starting from higher Addresses
        for (ptr_sw_stack=(ramStartAddress + (ramSize-1));ptr_sw_stack>=(ramStartAddress);ptr_sw_stack--) 
         {  
            ssl_RamTestResult =  ReadZero();

			 if ( !ssl_RamTestResult)
             return MARCHC_RAM_STACK_TEST_FAIL;
         }


/*Test the Software Stack region*/
      ssl_RamTestResult= MarchCSoftwareStackTest();


/* erase all sram */
      for(ptr_sw_stack=ramStartAddress; ptr_sw_stack<ramStartAddress + MARCHC_SOFTWARE_STACK_LENGTH; ptr_sw_stack++)
         *ptr_sw_stack=0;
    

/************************************* Testing Hardware Stack ******************************************/

/*save the return address in array*/
    WREG=TOSL;
	arr[0]=WREG;
    WREG=TOSH;
	arr[1]=WREG;
    WREG=TOSU;
	arr[2]=WREG;


/* Initialize a pointer pointing to a RAM address from where the stack needs to be saved before testing*/
      	S_ptr = (char *)ramStartAddress;
	
/* save the stack pointer */
		*(S_ptr++)=STKPTR;


/*Save the stack region in the RAM region*/
        for (STKPTR_Var = (MARCHC_HARDWARE_STACK_START_ADDRESS); STKPTR_Var <= (MARCHC_HARDWARE_STACK_END_ADDRESS) ; STKPTR_Var++)
      	  {
			STKPTR = STKPTR_Var;
			
       		 *( S_ptr++) = TOSL ;
             *( S_ptr++) = TOSH ;
             *( S_ptr++) = TOSU ;
		  }


 /*Test the Hardware Stack region*/
 


/* write 0 in stack locations which has to be tested */
	    for(STKPTR_Var=MARCHC_HARDWARE_STACK_START_ADDRESS; STKPTR_Var<=(MARCHC_HARDWARE_STACK_END_ADDRESS); STKPTR_Var++)
         {
			STKPTR = STKPTR_Var;          
          
             TOS=0x000000;
         }


/*Test Bitwise if 0 and replace it with 1 from low Address*/
   	    for(STKPTR_Var=MARCHC_HARDWARE_STACK_START_ADDRESS; STKPTR_Var<=(MARCHC_HARDWARE_STACK_END_ADDRESS); STKPTR_Var++)
         {
			STKPTR = STKPTR_Var;

			for (LoopCounter=MARCHC_HARDWARE_STACK_BIT_WIDTH-1;LoopCounter>=0;LoopCounter--)
              {


				  TempValue =(((TOS)>>LoopCounter) & 0x000001);  // read 0
                  if (TempValue!= 0x00)
                     {
						ssl_HardwareStackTestResult = MARCHC_HARDWARE_STACK_TEST_FAIL;
						goto MARCHC_HARDWARE_STACK_TEST_COMPLETE;
                     }

                  TOS=(TOS | (1<<LoopCounter));            		 // write 1

              }

         }



 /*Test Bitwise if 1 and replace it with 0 starting from lower Addresses */
       for(STKPTR_Var=MARCHC_HARDWARE_STACK_START_ADDRESS; STKPTR_Var<=(MARCHC_HARDWARE_STACK_END_ADDRESS); STKPTR_Var++)
         {
			STKPTR = STKPTR_Var;
			
          for (LoopCounter=0;LoopCounter<MARCHC_HARDWARE_STACK_BIT_WIDTH ;LoopCounter++)
              {


                  TempValue =(((TOS)>>LoopCounter) & 0x000001);     // read 1

		          if (TempValue!= 0x01)
     			    {

						 ssl_HardwareStackTestResult = MARCHC_HARDWARE_STACK_TEST_FAIL;
						 goto MARCHC_HARDWARE_STACK_TEST_COMPLETE;
						 
                     }

			if (LoopCounter<8)
 		 	      TOSL =  TOSL  & ~(0x01<<LoopCounter);             // write 0

			else if (LoopCounter>15)
 		 	      TOSU =  TOSU  & ~(0x01<<(LoopCounter-0x10));

			else
 		 	      TOSH =  TOSH  & ~(0x01<<(LoopCounter-8));


                }


      }



 //Test if all bits are zeros starting from lower Addresses
        for(STKPTR_Var=MARCHC_HARDWARE_STACK_START_ADDRESS; STKPTR_Var<=(MARCHC_HARDWARE_STACK_END_ADDRESS);STKPTR_Var++ )
         {
			STKPTR = STKPTR_Var;
			
            for (LoopCounter=0;LoopCounter<MARCHC_HARDWARE_STACK_BIT_WIDTH ;LoopCounter++)
              {

                 TempValue =(((TOS)>>LoopCounter) & 0x000001);    // read 0

        		 if (TempValue!= 0x00)
 					 {

						 ssl_HardwareStackTestResult = MARCHC_HARDWARE_STACK_TEST_FAIL;
						 goto MARCHC_HARDWARE_STACK_TEST_COMPLETE;
						 
                     }

	          }

         }

/* Test Bitwise if 0 and replace it with 1 starting from higher Addresses */
        for (STKPTR_Var=(MARCHC_HARDWARE_STACK_END_ADDRESS); STKPTR_Var>=(MARCHC_HARDWARE_STACK_START_ADDRESS); STKPTR_Var--)
           {
			STKPTR = STKPTR_Var;
			
             for (LoopCounter=MARCHC_HARDWARE_STACK_BIT_WIDTH-1;LoopCounter>=0;LoopCounter--)
              {

                TempValue =(((TOS)>>LoopCounter) & 0x000001);         // read 0
                if (TempValue!= 0x00)

                    {

						 ssl_HardwareStackTestResult = MARCHC_HARDWARE_STACK_TEST_FAIL;
						 goto MARCHC_HARDWARE_STACK_TEST_COMPLETE;
						 
                     }

                  TOS=(TOS | (1<<LoopCounter));                 // write 1

              }
          }




/* Test Bitwise if 1 and replace it with 0 starting from higher Addresses */
        for (STKPTR_Var=(MARCHC_HARDWARE_STACK_END_ADDRESS); STKPTR_Var>=(MARCHC_HARDWARE_STACK_START_ADDRESS);STKPTR_Var--)
         {
			STKPTR = STKPTR_Var;
			
    		 for (LoopCounter=0;LoopCounter<MARCHC_HARDWARE_STACK_BIT_WIDTH ;LoopCounter++)
              {

                  TempValue =(((TOS)>>LoopCounter) & 0x000001);     // read 1

		          if (TempValue!= 0x01)

					 {
						 ssl_HardwareStackTestResult = MARCHC_HARDWARE_STACK_TEST_FAIL;
						 goto MARCHC_HARDWARE_STACK_TEST_COMPLETE;
						 
                     }


 		 	  if (LoopCounter<8)
 		 	      TOSL =  TOSL  & ~(0x01<<LoopCounter);            // write 0

			else if (LoopCounter>15)
 		 	      TOSU =  TOSU  & ~(0x01<<(LoopCounter-0x10));

			else
 		 	      TOSH =  TOSH  & ~(0x01<<(LoopCounter-8));

			}
         }

/* Test if all bits are zeros starting from higher Addresses */
        for (STKPTR_Var=(MARCHC_HARDWARE_STACK_END_ADDRESS); STKPTR_Var>=(MARCHC_HARDWARE_STACK_START_ADDRESS);STKPTR_Var--)
         {
			STKPTR = STKPTR_Var;

            for (LoopCounter=0;LoopCounter<MARCHC_HARDWARE_STACK_BIT_WIDTH ;LoopCounter++)
              {

                 TempValue =(((TOS)>>LoopCounter) & 0x000001);    // read 0

        		 if (TempValue!= 0x00)

					 {

						 ssl_HardwareStackTestResult = MARCHC_HARDWARE_STACK_TEST_FAIL;
						 goto MARCHC_HARDWARE_STACK_TEST_COMPLETE;
						 
                     }

               }

         }


ssl_HardwareStackTestResult = MARCHC_HARDWARE_STACK_TEST_PASS;
	
MARCHC_HARDWARE_STACK_TEST_COMPLETE:      

 /* restore the stack region*/
        S_ptr--;

        for (STKPTR_Var =(MARCHC_HARDWARE_STACK_END_ADDRESS); STKPTR_Var >=(MARCHC_HARDWARE_STACK_START_ADDRESS); STKPTR_Var--)
          {
			STKPTR = STKPTR_Var;
			
              TOSU = *( S_ptr--) ;
			  TOSH = *( S_ptr--) ;
		      TOSL = *( S_ptr--) ;

          }


/* restore stack pointer */

     STKPTR  =   *( S_ptr);

/*get the return address from array to stack */

WREG=arr[0];
TOSL=WREG;
WREG=arr[1];
TOSH=WREG;
WREG=arr[2];
TOSU=WREG;


        for(ptr_sw_stack=ramStartAddress; ptr_sw_stack<ramStartAddress + MARCHC_SOFTWARE_STACK_LENGTH; ptr_sw_stack++)
            *ptr_sw_stack=0;

 
        if ( ssl_RamTestResult == 1 && ssl_HardwareStackTestResult == 1 )
     	    return MARCHC_RAM_STACK_TEST_PASS;
        else 
        	 return MARCHC_RAM_STACK_TEST_FAIL; 


  

   } // End of function



 /********************************************************************************************
  * Function Name: ReadZeroWriteOne      
  * 
  * Description  : This function tests bitwise if a bit is zero and replace it with one.
  * 
  *
  * Input:
  *      ptr_sw_stack: Address location of the the bits to be tested 
  *						
  * Return Values:
  *     TEST_FAIL: return value = 0
  *     
  *     TEST_PASS: return value = 1 
*********************************************************************************************/


static int ReadZeroWriteOne()
    {
//	int  TempValue;  
//   int LoopCounter;

            for (LoopCounter_sw_stack=MARCHC_RAM_BIT_WIDTH-1;LoopCounter_sw_stack>=0;LoopCounter_sw_stack--)
              {
                     
				  TempValue_sw_stack =(((*ptr_sw_stack)>>LoopCounter_sw_stack) & 0x01);  // read 0 
                  if (TempValue_sw_stack!= 0x00) 
                     {
                         return MARCHC_RAM_STACK_TEST_FAIL;
                     } 
                  
                  *ptr_sw_stack=(*ptr_sw_stack | (1<<LoopCounter_sw_stack));             // write 1
          
              }

    return MARCHC_RAM_STACK_TEST_PASS;  
  
	}

 /*********************************************************************************************
 * Function Name:ReadOneWriteZero      
  * 
  * Description  :  This function tests bitwise if a bit is one and replace it with zero.
  *
  * Input:
  *      ptr_sw_stack: Address location of the the bits to be tested 
  *						
  * Return Values:
  *     TEST_FAIL: return value = 0
  *     
  *     TEST_PASS: return value = 1 

**********************************************************************************************/


static int ReadOneWriteZero() 

    {

//	int  TempValue;  
//    int LoopCounter;


          for (LoopCounter_sw_stack=0;LoopCounter_sw_stack<MARCHC_RAM_BIT_WIDTH ;LoopCounter_sw_stack++)
              {

                  TempValue_sw_stack =(((*ptr_sw_stack)>>LoopCounter_sw_stack) & 0x01);     // read 1 

		          if (TempValue_sw_stack!= 0x01) 
     			   {
            			return MARCHC_RAM_STACK_TEST_FAIL;
     			   }


 		 	      TempValue_sw_stack =  *ptr_sw_stack  & ~(1<<LoopCounter_sw_stack);       // write 0
                  *ptr_sw_stack= TempValue_sw_stack;     

                }
     return MARCHC_RAM_STACK_TEST_PASS; 
    }

/*********************************************************************************************
* Function Name:ReadZero      
  * 
  * Description  :  This function tests bitwise if all bits are zeros 

  * Input:
  *      ptr_sw_stack: Address location of the the bits to be tested 
  *						
  * Return Values:
  *     TEST_FAIL: return value = 0
  *     
  *     TEST_PASS: return value = 1
**********************************************************************************************/
static int ReadZero() 
     {

//	int  TempValue;  
//    int LoopCounter;

            for (LoopCounter_sw_stack=0;LoopCounter_sw_stack<MARCHC_RAM_BIT_WIDTH ;LoopCounter_sw_stack++)
              {

                 TempValue_sw_stack =(((*ptr_sw_stack)>>LoopCounter_sw_stack) & 0x01);    // read 0 

        		 if (TempValue_sw_stack!= 0x00) 
        		   {
                        return MARCHC_RAM_STACK_TEST_FAIL;
                   }

               }
    return MARCHC_RAM_STACK_TEST_PASS; 
     }






 /******************************************************************
  * Description:
  *     Function Name: MarchCSoftwareStackTest
  *     
  *     This function performs the stack test starting from address
  *     "MARCHC_SOFTWARE_STACK_START_ADDRESS" and length
  *     "MARCHC_SOFTWARE_STACK_LENGTH".
  * Return Values:
  *     MARCHC_RAM_STACK_TEST_FAIL :  \return value = 0<p />
  *     MARCHC_RAM_STACK_TEST_PASS :  \return value = 1
  *                                                                
  ******************************************************************/

static int MarchCSoftwareStackTest(){

      
 /* Initialize a pointer pointing to already tested RAM address where the stack needs to be saved before testing*/
      	S_ptr = (char *)MARCHC_RAMTEST_START_ADDRESS;

 /*Save the stack region in Tested RAM region*/

      	for (ptr_sw_stack = (char*)(MARCHC_SOFTWARE_STACK_START_ADDRESS); ptr_sw_stack < (char*)(MARCHC_SOFTWARE_STACK_START_ADDRESS+MARCHC_SOFTWARE_STACK_LENGTH) ; ptr_sw_stack++)
      	  { 
       		 *( S_ptr++) = *(ptr_sw_stack) ;
      	  }
      	  
      	  
      	       	  
 /* clear the stack region under test */

	    for(ptr_sw_stack=(char*)MARCHC_SOFTWARE_STACK_START_ADDRESS; ptr_sw_stack<(char*)(MARCHC_SOFTWARE_STACK_START_ADDRESS+MARCHC_SOFTWARE_STACK_LENGTH); ptr_sw_stack++)
         {  
             *ptr_sw_stack=0; 
         }


 //Test Bitwise if 0 and replace it with 1 from low Address
   	    for(ptr_sw_stack=(char*)MARCHC_SOFTWARE_STACK_START_ADDRESS; ptr_sw_stack<(char*)(MARCHC_SOFTWARE_STACK_START_ADDRESS+MARCHC_SOFTWARE_STACK_LENGTH); ptr_sw_stack++)
         {
  //           ssl_RamTestResult =  ReadZeroWriteOne();
             
             for (LoopCounter_sw_stack=MARCHC_RAM_BIT_WIDTH-1;LoopCounter_sw_stack>=0;LoopCounter_sw_stack--)
              {
	              
//			reading 0	              
//		            Avoid_FSR1_use= (*ptr_sw_stack)>>LoopCounter_sw_stack;
         
	 				WREG = *ptr_sw_stack;        
	                _asm
		            MOVFF LoopCounter_sw_stack, LoopCounter_sw_stack_temp
		            NOP
		            MOVLB 0
		            MOVF LoopCounter_sw_stack_temp, 1, BANKED
		            BZ shiftdone7
	shiftNotDone7:	RRNCF WREG, 1, ACCESS
		            ANDLW 0x7f
		            DECF LoopCounter_sw_stack_temp, 1, BANKED
		            BNZ shiftNotDone7
	shiftdone7:	    MOVWF Avoid_FSR1_use, BANKED      
	                _endasm             
                    
                    TempValue_sw_stack = Avoid_FSR1_use & 0x01;  					// read 0 
				  
                  if (TempValue_sw_stack!= 0x00) 
                     {
                        ssl_RamTestResult = MARCHC_RAM_STACK_TEST_FAIL;
                        goto SoftwareStackTestFail;
                     }
                      
// 			writing 1                                 
//					Avoid_FSR1_use=1<<LoopCounter_sw_stack;
					  _asm
					  MOVLW 0x1
					  MOVFF LoopCounter_sw_stack, LoopCounter_sw_stack_temp
					  NOP
					  MOVLB 0
					  MOVF LoopCounter_sw_stack_temp, 1, BANKED
					  BZ shiftdone6
	shiftNotDone6:	  RLNCF WREG, 1, ACCESS
					  ANDLW 0xfe
					  DECF LoopCounter_sw_stack_temp, 1, BANKED
					  BNZ shiftNotDone6
	shiftdone6:		  MOVWF Avoid_FSR1_use, BANKED
					 _endasm
					
				
				   	*ptr_sw_stack = *ptr_sw_stack | Avoid_FSR1_use;             // write 1

              }

    ssl_RamTestResult = MARCHC_RAM_STACK_TEST_PASS; 
    
            } 

 //Test Bitwise if 1 and replace it with 0 starting from lower Addresses
        for(ptr_sw_stack=(char*)MARCHC_SOFTWARE_STACK_START_ADDRESS; ptr_sw_stack<(char*)(MARCHC_SOFTWARE_STACK_START_ADDRESS+MARCHC_SOFTWARE_STACK_LENGTH); ptr_sw_stack++)
         {
            
//          ssl_RamTestResult =  ReadOneWriteZero();
           
          for (LoopCounter_sw_stack_unsigned=0;LoopCounter_sw_stack_unsigned<MARCHC_RAM_BIT_WIDTH ;LoopCounter_sw_stack_unsigned++)
              {

//		Reading 1
//                  TempValue_sw_stack =(((*ptr_sw_stack)>>LoopCounter_sw_stack_unsigned) & 0x01);     // read 1 

         //           Avoid_FSR1_use= (*ptr_sw_stack)>>LoopCounter_sw_stack_unsigned;
         
	 				WREG = *ptr_sw_stack;        
	                _asm
		            MOVFF LoopCounter_sw_stack_unsigned, LoopCounter_sw_stack_temp
		            NOP
		            MOVLB 0
		            MOVF LoopCounter_sw_stack_temp, 1, BANKED
		            BZ shiftdone5
	shiftNotDone5:	RRNCF WREG, 1, ACCESS
		            ANDLW 0x7f
		            DECF LoopCounter_sw_stack_temp, 1, BANKED
		            BNZ shiftNotDone5
	shiftdone5:	    MOVWF Avoid_FSR1_use, BANKED      
	           		_endasm             
                    
                    
				  TempValue_sw_stack = Avoid_FSR1_use & 0x01;  					// read 1 

		          if (TempValue_sw_stack!= 0x01) 
     			   {
            			ssl_RamTestResult = MARCHC_RAM_STACK_TEST_FAIL;
            			 goto SoftwareStackTestFail;
     			   }

				
//			Writing 0
 		 	      
//					Avoid_FSR1_use = ~(1<<LoopCounter_sw_stack_unsigned);
					  _asm
					  MOVLW 0x1
					  MOVFF LoopCounter_sw_stack_unsigned, LoopCounter_sw_stack_temp
					  NOP
					  MOVLB 0
					  MOVF LoopCounter_sw_stack_temp, 1, BANKED
					  BZ shiftdone9
shiftNotDone9:	  	  RLNCF WREG, 1, ACCESS
					  ANDLW 0xfe
					  DECF LoopCounter_sw_stack_temp, 1, BANKED
					  BNZ shiftNotDone9
shiftdone9:			  COMF WREG, 0, ACCESS
					  MOVWF Avoid_FSR1_use, BANKED
					  _endasm
					
				
				   	*ptr_sw_stack = *ptr_sw_stack & Avoid_FSR1_use;             // write 0
				   	
              
                  }
                  
     ssl_RamTestResult = MARCHC_RAM_STACK_TEST_PASS;
        
         }                  

 //Test if all bits are zeros starting from lower Addresses
        for(ptr_sw_stack=(char*)MARCHC_SOFTWARE_STACK_START_ADDRESS; ptr_sw_stack<(char*)(MARCHC_SOFTWARE_STACK_START_ADDRESS+MARCHC_SOFTWARE_STACK_LENGTH); ptr_sw_stack++)
         {
            
//           ssl_RamTestResult =  ReadZero();
            
            for (LoopCounter_sw_stack_unsigned=0;LoopCounter_sw_stack_unsigned<MARCHC_RAM_BIT_WIDTH ;LoopCounter_sw_stack_unsigned++)
              {

//			Reading 0
//                 TempValue_sw_stack =(((*ptr_sw_stack)>>LoopCounter_sw_stack_unsigned) & 0x01);    // read 0 

//		           Avoid_FSR1_use= (*ptr_sw_stack)>>LoopCounter_sw_stack_unsigned;
         
	 				WREG = *ptr_sw_stack;        
	                _asm
		            MOVFF LoopCounter_sw_stack_unsigned, LoopCounter_sw_stack_temp
		            NOP
		            MOVLB 0
		            MOVF LoopCounter_sw_stack_temp, 1, BANKED
		            BZ shiftdone4
	shiftNotDone4:	RRNCF WREG, 1, ACCESS
		            ANDLW 0x7f
		            DECF LoopCounter_sw_stack_temp, 1, BANKED
		            BNZ shiftNotDone4
	shiftdone4:	    MOVWF Avoid_FSR1_use, BANKED      
	           		_endasm             
                    
                    
				  	TempValue_sw_stack = Avoid_FSR1_use & 0x01;  // read 0 

        		 if (TempValue_sw_stack!= 0x00) 
        		   {
                       ssl_RamTestResult= MARCHC_RAM_STACK_TEST_FAIL;
                       goto SoftwareStackTestFail;
                   }

               }
    ssl_RamTestResult= MARCHC_RAM_STACK_TEST_PASS;

         }

//Test Bitwise if 0 and replace it with 1 starting from higher Addresses
        for (ptr_sw_stack=(char*)(MARCHC_SOFTWARE_STACK_START_ADDRESS+MARCHC_SOFTWARE_STACK_LENGTH -1);ptr_sw_stack>=(char*)(MARCHC_SOFTWARE_STACK_START_ADDRESS);ptr_sw_stack--) 
         {  

//      	  ssl_RamTestResult =  ReadZeroWriteOne();
        	  
             for (LoopCounter_sw_stack=MARCHC_RAM_BIT_WIDTH-1;LoopCounter_sw_stack>=0;LoopCounter_sw_stack--)
              {

//		Reading 0                     
//				  TempValue_sw_stack =(((*ptr_sw_stack)>>LoopCounter_sw_stack) & 0x01);  // read 0 

//	              Avoid_FSR1_use= (*ptr_sw_stack)>>LoopCounter_sw_stack;
         
	 				WREG = *ptr_sw_stack;        
	                _asm
		            MOVFF LoopCounter_sw_stack, LoopCounter_sw_stack_temp
		            NOP
		            MOVLB 0
		            MOVF LoopCounter_sw_stack_temp, 1, BANKED
		            BZ shiftdone2
	shiftNotDone2:	RRNCF WREG, 1, ACCESS
		            ANDLW 0x7f
		            DECF LoopCounter_sw_stack_temp, 1, BANKED
		            BNZ shiftNotDone2
	shiftdone2:	    MOVWF Avoid_FSR1_use, BANKED      
	           		_endasm             
                    
                    TempValue_sw_stack = Avoid_FSR1_use & 0x01; 				 // read 0 
				  
                  if (TempValue_sw_stack!= 0x00) 
                     {
                        ssl_RamTestResult = MARCHC_RAM_STACK_TEST_FAIL;
                        goto SoftwareStackTestFail;
                     } 

//		Writing 1                
//                  *ptr_sw_stack=(*ptr_sw_stack | (1<<LoopCounter_sw_stack));             // write 1

//					Avoid_FSR1_use=1<<LoopCounter_sw_stack;
					  _asm
					  MOVLW 0x1
					  MOVFF LoopCounter_sw_stack, LoopCounter_sw_stack_temp
					  NOP
					  MOVLB 0
					  MOVF LoopCounter_sw_stack_temp, 1, BANKED
					  BZ shiftdone3
	shiftNotDone3:	  RLNCF WREG, 1, ACCESS
					  ANDLW 0xfe
					  DECF LoopCounter_sw_stack_temp, 1, BANKED
					  BNZ shiftNotDone3
	shiftdone3:		  MOVWF Avoid_FSR1_use, BANKED
					  _endasm
					
					  *ptr_sw_stack = *ptr_sw_stack | Avoid_FSR1_use;             // write 1
				   	
                 
          		}

    ssl_RamTestResult = MARCHC_RAM_STACK_TEST_PASS; 
    
         }
//Test Bitwise if 1 and replace it with 0 starting from higher Addresses
        for (ptr_sw_stack=(char*)(MARCHC_SOFTWARE_STACK_START_ADDRESS+MARCHC_SOFTWARE_STACK_LENGTH -1);ptr_sw_stack>=(char*)(MARCHC_SOFTWARE_STACK_START_ADDRESS);ptr_sw_stack--) 
         {  
//           ssl_RamTestResult =  ReadOneWriteZero();
            
          for (LoopCounter_sw_stack_unsigned=0;LoopCounter_sw_stack_unsigned<MARCHC_RAM_BIT_WIDTH ;LoopCounter_sw_stack_unsigned++)
              {

//		Reading 1
//                  TempValue_sw_stack =(((*ptr_sw_stack)>>LoopCounter_sw_stack_unsigned) & 0x01);     // read 1 

//		            Avoid_FSR1_use= (*ptr_sw_stack)>>LoopCounter_sw_stack_unsigned;
         
	 				WREG = *ptr_sw_stack;        
	                _asm
		            MOVFF LoopCounter_sw_stack_unsigned, LoopCounter_sw_stack_temp
		            NOP
		            MOVLB 0
		            MOVF LoopCounter_sw_stack_temp, 1, BANKED
		            BZ shiftdone8
	shiftNotDone8:	RRNCF WREG, 1, ACCESS
		            ANDLW 0x7f
		            DECF LoopCounter_sw_stack_temp, 1, BANKED
		            BNZ shiftNotDone8
	shiftdone8:	    MOVWF Avoid_FSR1_use, BANKED      
	           		_endasm             
                    
                    
				  	TempValue_sw_stack = Avoid_FSR1_use & 0x01;  // read 0 
				  

		          if (TempValue_sw_stack!= 0x01) 
     			   {
            			ssl_RamTestResult = MARCHC_RAM_STACK_TEST_FAIL;
            			 goto SoftwareStackTestFail;
     			   }

//		Writing 1					
//					Avoid_FSR1_use = ~(1<<LoopCounter_sw_stack_unsigned);
					  _asm
					  MOVLW 0x1
					  MOVFF LoopCounter_sw_stack_unsigned, LoopCounter_sw_stack_temp
					  NOP
					  MOVLB 0
					  MOVF LoopCounter_sw_stack_temp, 1, BANKED
					  BZ shiftdone10
	shiftNotDone10:	  RLNCF WREG, 1, ACCESS
					  ANDLW 0xfe
					  DECF LoopCounter_sw_stack_temp, 1, BANKED
					  BNZ shiftNotDone10
	shiftdone10:	  COMF 0xfe8, 0, ACCESS
					  MOVWF Avoid_FSR1_use, BANKED
					  _endasm
					
				
				   	  *ptr_sw_stack = *ptr_sw_stack & Avoid_FSR1_use;             // write 0

                }
     ssl_RamTestResult = MARCHC_RAM_STACK_TEST_PASS;
     
         }

//Test if all bits are zeros starting from higher Addresses
        for (ptr_sw_stack=(char*)(MARCHC_SOFTWARE_STACK_START_ADDRESS+MARCHC_SOFTWARE_STACK_LENGTH-1);ptr_sw_stack>=(char*)(MARCHC_SOFTWARE_STACK_START_ADDRESS);ptr_sw_stack--) 
         {  
//           ssl_RamTestResult =  ReadZero();
 
             for (LoopCounter_sw_stack_unsigned=0;LoopCounter_sw_stack_unsigned<MARCHC_RAM_BIT_WIDTH ;LoopCounter_sw_stack_unsigned++)
              {

//		Reading 0
//                 TempValue_sw_stack =(((*ptr_sw_stack)>>LoopCounter_sw_stack_unsigned) & 0x01);    // read 0 

//		           Avoid_FSR1_use= (*ptr_sw_stack)>>LoopCounter_sw_stack_unsigned;
         
	 				WREG = *ptr_sw_stack;        
	                _asm
		            MOVFF LoopCounter_sw_stack_unsigned, LoopCounter_sw_stack_temp
		            NOP
		            MOVLB 0
		            MOVF LoopCounter_sw_stack_temp, 1, BANKED
		            BZ shiftdone1
	shiftNotDone1:	RRNCF WREG, 1, ACCESS
		            ANDLW 0x7f
		            DECF LoopCounter_sw_stack_temp, 1, BANKED
		            BNZ shiftNotDone1
	shiftdone1:	    MOVWF Avoid_FSR1_use, BANKED      
	          		_endasm             
                    
                    
				  	TempValue_sw_stack = Avoid_FSR1_use & 0x01;  // read 0 

        		 if (TempValue_sw_stack!= 0x00) 
        		   {
                       ssl_RamTestResult= MARCHC_RAM_STACK_TEST_FAIL;
                       goto SoftwareStackTestFail;
                   }

               }
    ssl_RamTestResult= MARCHC_RAM_STACK_TEST_PASS;

         }     

SoftwareStackTestFail:
			/* restore the stack region*/
           	S_ptr = (char *)MARCHC_RAMTEST_START_ADDRESS;
         	for (ptr_sw_stack =(char *)(MARCHC_SOFTWARE_STACK_START_ADDRESS); ptr_sw_stack < (char *)(MARCHC_SOFTWARE_STACK_START_ADDRESS+MARCHC_SOFTWARE_STACK_LENGTH); ptr_sw_stack++)
          	{ 
              *(ptr_sw_stack) = *( S_ptr++) ;
          	}




           if ( !ssl_RamTestResult)
             return MARCHC_RAM_STACK_TEST_FAIL;
           else         
   			return MARCHC_RAM_STACK_TEST_PASS;
   
}