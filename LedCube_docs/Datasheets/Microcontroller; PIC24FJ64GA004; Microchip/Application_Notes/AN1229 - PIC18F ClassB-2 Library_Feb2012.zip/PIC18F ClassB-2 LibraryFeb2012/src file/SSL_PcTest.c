
/*****************************************************************************************
* � 2008  Microchip Technology Inc. 
* 
* FileName:		    SSL_PcTest.c
* Dependencies:     Header (.h) files if applicable, see below
* Processor:		PIC18F
* Compiler:		    MPLAB� C18 V3.21 or higher
* Company:	    	Microchip Technology, Inc.
* Version :         1.0
* Date :            10/01/08   (mm/dd/yy)
* Author:           Arpan Kumar
*
* Software License Agreement:
*
* Microchip licenses this software to you solely for use with Microchip products.
* The software is owned by Microchip and its licensors, and is protected under
* applicable copyright laws.  All rights reserved.
* SOFTWARE IS PROVIDED �AS IS.�  MICROCHIP EXPRESSLY DISCLAIMS ANY WARRANTY OF ANY 
* KIND, WHETHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO, THE IMPLIED 
* WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT.
* IN NO EVENT SHALL MICROCHIP BE LIABLE FOR ANY INCIDENTAL, SPECIAL, INDIRECT OR 
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, HARM TO YOUR EQUIPMENT, COST 
* OF PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY OR SERVICES, ANY CLAIMS BY THIRD
* PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), ANY CLAIMS FOR INDEMNITY
* OR CONTRIBUTION, OR OTHER SIMILAR COSTS.
* To the fullest extent allowed by law, Microchip and its licensors liability shall
* not exceed the amount of fees, if any, that you have paid directly to Microchip 
* to use this software.
* MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE TERMS.
*
*
* REVISION HISTORY:
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* Author            Date      Comments on this revision
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* AKA                         First release of source file
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
*
**********************************************************************/
#include "..\h\SSL_PcTest.h"


  /*******************************************************************
  * Description:
  * The Program Counter test is a functional test of the PC. The PC holds the address 
  * of the next instruction tO be executed.
  * The tests performs the following major tasks:
  *		1. The Program Counter test invokes functions that are located in Flash memory at different addresses.
  *		2. These functions return a unique value( address of the respective functions).
  *		3. The returned value is verified using the "SSL_8bitsFamily_PCtesT" function.
  * Return Values:
  *     PC_TEST_FAIL :  return value = 0.
  *     PC_TEST_PASS :  return value = 1.
  *                                                                    
  *******************************************************************/

int SSL_8bitsFamily_PCtest ()
{

	 long returnAddress,tempAddress;

    //store Address of SSL_TestFunction1
 	tempAddress= (long)&SSL_TestFunction1;

    // Branch to SSL_TestFunction1
    returnAddress=SSL_TestFunction1();

    // Test if the address of "SSL_TestFunction1" returned is the same
		if( tempAddress != returnAddress)
  		 	return PC_TEST_FAIL;

   // store Address of SSL_TestFunction2
 	tempAddress= (long )&SSL_TestFunction2;

   // Branch to SSL_TestFunction2
 	returnAddress=SSL_TestFunction2();

   // Test if the address of "SSL_TestFunction2" returned is the same
		if( tempAddress != returnAddress)
  			 return PC_TEST_FAIL;  


  return PC_TEST_PASS;

}



  /********************************************************************
  * Description:
  * This function is placed in the section called "SslTestSection1".The section
  * is located in a defined address where the PC needs to jump using the custom linker script,
  * This function returns the address of the SSL_TestFunction1. 
  * In this example the function SSL_TestFunction1 is placed in a section page1 at the 
  * address 0xd00e.
  *
  * 
  *
  * Return Values:     
  *      returnAddress: returns the address of SSL_TestFunction1
  *
  ********************************************************************/
#pragma code page1=0x600e

long  SSL_TestFunction1() 
{

	return( (long)&SSL_TestFunction1);

}

/********************************************************************
  * Description:
  *  This function is placed in the section called "page2".The section
  * is located in a defined address d10e.
  * This function returns the address of the SSL_TestFunction2.
  * Return Values:     
  *      returnAddress: returns the address of SSL_TestFunction2
  *            
  ********************************************************************/

#pragma code page2=0x610e

long SSL_TestFunction2() 
{

	return( (long)&SSL_TestFunction2);

}
