 Company:Microchip Technology, Inc.
 Author: Arpan Kumar(I00213)


This file is a guide on the test cases for CLASSB self testing, the way it
needs to be run and settings required for them.

The self test was performed on 18F4620 and 18F45J10 devices and tested.



The project along with the codes is ready to work for the device 18F4620,but if
other device is being used then following changes might be required in order to 
compile the code without error:

1. The device which does not have EEPROM, should not include "SSL_EEPROMTest_CRC16.c"
   source file in their project and the part of main file where this test is being
   called should also be commented.
2. Configuration bit settings are changed through software in the file "main.c",
   some device does not support these instructions, so either the instructions 
   has to be changed depending on the device, or comment those instructions and 
   change the configuration bits in the MPLAB IDE.
3. OSCCON register contents are changed in "main.c" in order to run the code on
   8MHz internal clock, but for some devices external oscillator has to be used 
   to get 8MHz clock. In that case, comment the instruction and change the 
   configuration bit accordingly.
4. linker script of the device has to be added in the project.




The following are the different test modules:

1. SSL_CheckerBoardTest.asm
2. SSL_CpuRegisterTest.asm 
3. SSL_ClockTest_LineFreq.c
4. SSL_ClockTest.c
5. SSL_EEPROMTest_CRC16.c
6. SSL_FlashTest_CRC16.c
7. SSL_MarchBRamTest.c
8. SSL_MarchC_MinusRamTest.c
9. SSL_MarchC_RamAndStackTest.c
10.SSL_MarchRamTest.c
11.SSL_PcTest.c


1. SSL_CheckerBoardTest.asm:
	
	This test uses checker board algorithm to test the RAM of the device. 
There are 2 Macros, SIZE and START_RAM, defined in the SSL_CheckerBoardTest.INC file. 
SIZE is a constant which says how many locations of RAM have to be tested (in bytes). 
It has to be an even number between 0x00 - 0xFE. 

START_RAM must have the starting address of the RAM from where the test has to be
started. It can not be 000h or 001h or 002h, as these locations are being used
to store variables.

Result:	The test return a value 'RAM_Test_Pass' in the W register if RAM
locations are working fine otherwise it returns 'RAM_Test_Fail'.



2. SSL_CpuRegisterTest.asm:

	This test checks the core registers (no peripheral registers are tested)
of the device by writing a value (usually 55h & AAh) to them and then reading 
back the same. An array (by name 'Reg_save') of 8 bytes has been reserved in the
RAM for saving the registers content. W and STATUS registers are not saved as 
they are automatically saved before calling a function.

Result: The test return a value 'Register_Test_Pass' in the W register if all 
the registers are working fine otherwise it returns 'Register_Test_Fail'.



3. SSL_ClockTest_LineFreq.c:

	A 50/60 Hz signal has to be given at CCP1 pin of the device (its better
to give this signal before running the test), and the corresponding bit has to 
be set in "SSL_ClockTest_LineFreq.h" file prior to run the test. If no signal 
is given on the CCP1 pin then the execution will get stuck in the first while
loop of "SSL_ClockTest_LineFreq.c" file. The expected range of count values 
given in .h file is for 8MHz clock, so the device should be running on 8MHz 
oscillator for the test to work. the source of 8MHz clock has to be properly 
changed in main file and/or configuration bit setting.

Result: The test return a value 'Clock_No_Error' if there is no error in clock
otherwise it returns 'Clock_Error'.


4. SSL_ClockTest.c:

	For this test a timer1 oscillator of 32KHz freq is used as reference
clock.The expected range of count values given in "SSL_ClockTest.h" file is for
8MHz clock, so the device should be running on 8MHz oscillator for the test to 
work. the source of 8MHz clock has to be properly changed in main file and/or 
configuration bit setting.

Result: The test return a value 'Clock_No_Error' if there is no error in clock
otherwise it returns 'Clock_Error'.



5. SSL_EEPROMTest_CRC16.c:

	The devices which do not have EEPROM, should not include this source
file in their project and the part of main file where this test is being called
should also be commented. 

Result: This test does not affect the 'Testflag structure', defined to show the 
device working status directly, rather it will store a CRC checksum value in the
variable by name 'eeprom_crc_Result'. User has to run the test after some time 
again and see whether this variable is giving the same value or not. if it is
having different value, that means EEPROM content is changed.
 


6. SSL_FlashTest_CRC16.c:

	Flash start address and flash end adress has to be given properly such
that it does not go beyond the limit of implemented flash of the perticular device.

Result: same as EEPROM test this test does not affect the 'Testflag structure'
defined to show the device working status directly, rather it will store a CRC 
checksum value in the variable by name 'flash_crc_Result'.User has to run the
test after some time again and see whether this variable is giving the same 
value or not. if it is having different value, that means flash memory is changed.



7. RAM tests:

	RAM start address and RAM size should be appropriate for the perticular
device under test.

 To invoke the "SSL_8bitsFamily_RAMtest_MarchC" function, include the file 
"SSL_MarchCRamTest.c" comment the "SSL_16bitsFamily_RAM_STACKtest_MarchC" 
function and remove the "SSL_MarchCRamAndStackTest.c" from the workspace.

Results: It returns a value 'Ram_Test_pass' if RAM works fine otherwise it 
returns 'Ram_Test_fail'.




8. SSL_MarchC_RamAndStackTest.c:

	 This test is for Hardware Stack, Software Stack and RAM all in one.
STACK start address and STACK size should be appropriate for the 
perticular device under test.RAM start address, where the stack content will be 
saved first, should also be approprite for the perticular device.
The "Software Stack Start Address" from which the March C test is to be performed 
must be with in the range of allocated Stack area in linker file of the device.

To invoke this test include the file "SSL_MarchC_RamAndStackTest.c" comment
the "SSL_8bitsFamily_RAMtest_MarchC" function and remove the "SSL_MarchCRamTest.c"
from the workspace.

Result: returns a value 'MARCHC_RAM_STACK_TEST_PASS' if selected Stack and RAM works well, otherwise
it returns 'MARCHC_RAM_STACK_TEST_FAIL'.



9. SSL_PcTest.c:

	this file has two call sub-routines in it, starting from a perticular
address. these addresses should be appropriate as per the device used.

Result: It returns a value 'PC_TEST_PASS' if PC works fine otherwise it returns
'PC_TEST_FAIL'.
