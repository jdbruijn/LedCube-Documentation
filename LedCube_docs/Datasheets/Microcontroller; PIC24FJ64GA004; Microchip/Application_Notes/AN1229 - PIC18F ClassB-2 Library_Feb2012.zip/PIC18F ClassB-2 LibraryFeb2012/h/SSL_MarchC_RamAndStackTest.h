/*****************************************************************************************
* � 2008  Microchip Technology Inc.
*
* FileName:		    SSL_MarchcStackTest.h
* Dependencies:     Header (.h) files if applicable, see below
* Processor:		PIC18F
* Compiler:		    MPLAB� C18 V3.21 or higher
* Company:	    	Microchip Technology, Inc.
* Version :         1.0
* Date :            10/01/08   (mm/dd/yy)
* Author:           Arpan Kumar
*
* Software License Agreement:
*
* Microchip licenses this software to you solely for use with Microchip products.
* The software is owned by Microchip and its licensors, and is protected under
* applicable copyright laws.  All rights reserved.
* SOFTWARE IS PROVIDED �AS IS.�  MICROCHIP EXPRESSLY DISCLAIMS ANY WARRANTY OF ANY
* KIND, WHETHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT.
* IN NO EVENT SHALL MICROCHIP BE LIABLE FOR ANY INCIDENTAL, SPECIAL, INDIRECT OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, HARM TO YOUR EQUIPMENT, COST
* OF PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY OR SERVICES, ANY CLAIMS BY THIRD
* PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), ANY CLAIMS FOR INDEMNITY
* OR CONTRIBUTION, OR OTHER SIMILAR COSTS.
* To the fullest extent allowed by law, Microchip and its licensors liability shall
* not exceed the amount of fees, if any, that you have paid directly to Microchip
* to use this software.
* MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE TERMS.
*
*
* REVISION HISTORY:
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* Author            Date            Comments on this revision
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* AK                                First release of include file
* AK                13 May 2010     Added Software stack test
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
*
**********************************************************************/

#ifndef __SSL_MARCHC_RAM_AND_STACK_TEST_H__
#define __SSL_MARCHC_RAM_AND_STACK_TEST_H__



 /****************************************************************
 * The Start Address from which the March C test for RAM is to be
 * performed. Later Stack content is also saved in the locations 
 * starting from this address.This area should not be overlapping 
 * with software stack area defined in linker file of the device.                                             
 *****************************************************************/
#define MARCHC_RAMTEST_START_ADDRESS 0X300

/*The number of RAM bytes to be tested.*/
#define MARCHC_RAMTEST_SIZE          0X100

 /****************************************************************
 * The Sostware Stack Start Address from which the March C test is
 * to be performed. This Address must be with in the range of allocated 
 * software Stack area in linker file of the device                                              
 ****************************************************************/

#define MARCHC_SOFTWARE_STACK_START_ADDRESS  0X500	

/*Stack size in bytes.*/
		 
#define MARCHC_SOFTWARE_STACK_LENGTH         0XFF   
         
/*The Data width is 8 bits for PIC18F devices.*/

#define MARCHC_RAM_BIT_WIDTH   8        
      
#define MARCHC_RAM_STACK_TEST_PASS 1

#define MARCHC_RAM_STACK_TEST_FAIL 0

extern int ssl_RamTestResult;

/* Hardware Stack Start Address should always be less than Hardware Stack End Address */

 /****************************************************************
 * The Hardware Stack Start Address from which the March C test is
 * to be performed. 
 ****************************************************************/

#define MARCHC_HARDWARE_STACK_START_ADDRESS  0X01		// Hardware stack is implimented from address 0X01, address 0X00 is kept empty and its not usable. so this value should not be less than 0X01

 /****************************************************************
 * The Hardware Stack End Address till which the March C test is
 * to be performed.
 ****************************************************************/

#define MARCHC_HARDWARE_STACK_END_ADDRESS    0X1F		// Hardware stack is implimented only till 0X1F, so this value should not go beyond that

/*The Data width is 21 bits for PIC18F hardware stack.*/

#define MARCHC_HARDWARE_STACK_BIT_WIDTH   21

#define MARCHC_HARDWARE_STACK_TEST_PASS 1

#define MARCHC_HARDWARE_STACK_TEST_FAIL 0

extern int ssl_HardwareStackTestResult;


//Function Declarations

int SSL_8bitsFamily_RAM_STACKtest_MarchC(char *, unsigned int);

#endif
