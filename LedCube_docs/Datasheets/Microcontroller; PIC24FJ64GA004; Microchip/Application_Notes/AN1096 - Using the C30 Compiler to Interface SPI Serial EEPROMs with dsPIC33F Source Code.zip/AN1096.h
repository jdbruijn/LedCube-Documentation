
/********************************************************************
 *                                                                    
 *                     Software License Agreement                      
 *                                                                     
 * The software supplied herewith by Microchip Technology Incorporated 
 * (the "Company") for its PICmicro� Microcontroller is intended and   
 * supplied to you, the Company�s customer, for use solely and         
 * exclusively on Microchip PICmicro Microcontroller products.         
 *                                                                     
 * The software is owned by the Company and/or its supplier, and is     
 * protected under applicable copyright laws. All rights are reserved.  
 * Any use in violation of the foregoing restrictions may subject the  
 * user to criminal sanctions under applicable laws, as well as to     
 * civil liability for the breach of the terms and conditions of this  
 * license.                                                             
 *                                                                      
 * THIS SOFTWARE IS PROVIDED IN AN "AS IS" CONDITION. NO WARRANTIES,   
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED   
 * TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A         
 * PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,   
 * IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR          
 * CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.                    
 *                                                                     
 *******************************************************************
 *
 *  Filename:           AN1096.h
 *  Date:               May 11, 2007
 *  File Version:       1.0
 *  Compiled using:     MPLAB IDE 7.50
 *                      MPLAB C30 2.40
 *
 *  Author:             Martin Kvasnicka
 *  Company:            Microchip Technology Inc.
 *
 ******************************************************************/

#ifndef	__AN1096_H
#define	__AN1096_H

/** D E F I N E S **************************************************/
#define WREN        0b00000110          // WREN command
#define WRDI        0b00000100          // WRDI command
#define WRITE       0b00000010          // WRITE command
#define READ        0b00000011          // READ command
#define WRSR        0b00000001          // WRSR command
#define RDSR        0b00000101          // RDSR command
#define CS          PORTFbits.RF2       // Chip select pin, PORTA pin 3
#define SCK         PORTFbits.RF6       // Clock pin, PORTB pin 0
#define SO          PORTFbits.RF8       // Serial output pin, PORTB pin 1
#define SI          PORTFbits.RF7       // Serial input pin, PORTB pin 4

/** P R O T O T Y P E S ********************************************/
void LowDensByteWrite(unsigned char,unsigned int);                  // Low-density Byte Write function
void LowDensByteRead(unsigned char*,unsigned int);                   // Low-density Byte Read function
void LowDensPageWrite(unsigned char*,unsigned int,unsigned char);   // Low-density Page Write function
void LowDensSeqRead(unsigned char*,unsigned int,unsigned char);     // Low-density Sequential Read function
void HighDensByteWrite(unsigned char,unsigned int);                 // High-density Byte Write function
void HighDensByteRead(unsigned char*,unsigned int);                  // High-density Byte Read function
void HighDensPageWrite(unsigned char*,unsigned int,unsigned char);  // High-density Page Write function
void HighDensSeqRead(unsigned char*,unsigned int,unsigned char);    // High-density Sequential Read function
unsigned char ReadStatusReg(void);                                  // Read Status Register function
void WriteStatusReg(unsigned char);                                 // Write Status Register function
void WriteEnable(void);                                             // Write Enable function
void WriteDisable(void);                                            // Write Disable function
void WIP_Poll(void);                                                // WIP polling function

#endif
