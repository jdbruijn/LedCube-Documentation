
/********************************************************************
 *                                                                    
 *                     Software License Agreement                      
 *                                                                     
 * The software supplied herewith by Microchip Technology Incorporated 
 * (the "Company") for its PICmicro� Microcontroller is intended and   
 * supplied to you, the Company�s customer, for use solely and         
 * exclusively on Microchip PICmicro Microcontroller products.         
 *                                                                     
 * The software is owned by the Company and/or its supplier, and is     
 * protected under applicable copyright laws. All rights are reserved.  
 * Any use in violation of the foregoing restrictions may subject the  
 * user to criminal sanctions under applicable laws, as well as to     
 * civil liability for the breach of the terms and conditions of this  
 * license.                                                             
 *                                                                      
 * THIS SOFTWARE IS PROVIDED IN AN "AS IS" CONDITION. NO WARRANTIES,   
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED   
 * TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A         
 * PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,   
 * IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR          
 * CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.                    
 *                                                                     
 *******************************************************************
 *
 *  Filename:           AN1096_SPI.c
 *  Date:               May 11, 2007
 *  File Version:       1.0
 *  Compiled using:     MPLAB IDE 7.50
 *                      MPLAB C18 2.40
 *
 *  Author:             Martin Kvasnicka
 *  Company:            Microchip Technology Inc.
 *
 *******************************************************************
 *
 *  Files required:     p18f1220.h
 *                      AN1018.h
 *
 ** I N C L U D E S ************************************************/
#include <p33fxxxx.h>
#include "AN1096.h"

/** P R I V A T E   P R O T O T Y P E S ****************************/
void byteout(unsigned char);            // Byte output function
unsigned char bytein(void);             // Byte input function

/********************************************************************
 * Function:        void LowDensByteWrite(unsigned char data,
 *                                        unsigned int address)
 *
 * Description:     This function performs a byte write operation for
 *                  low-density (<= 4 Kb) devices. It embeds the MSb
 *                  of the memory address into the instruction in
 *                  order to support the 25XX040X. After initiating
 *                  the write cycle, the WIP_Poll function is called
 *                  to determine the end of the cycle.
 *
 * Parameters:      data - Byte of data to be written
 *                  address - Memory location at which to start
 *******************************************************************/
void LowDensByteWrite(unsigned char data, unsigned int address)
{
    static unsigned char command;   // Temp. variable to store cmd.

    // First embed MSb of address (bit 8) into instruction
    command = address >> 5;         // Align MSb of address
    command &= 0x08;                // Mask off extra bits
    command |= WRITE;               // Merge in WRITE instruction

    WriteEnable();                  // Set WEL bit for write
    CS = 0;                         // Bring CS low (active)
    byteout(command);               // Output command & MSb of address
    byteout(address&0xFF);          // Output LSB of address
    byteout(data);                  // Write byte of data
    CS = 1;                         // Bring CS high (inactive)
    WIP_Poll();                     // Perform WIP polling
} // end of LowDensByteWrite(...)

/********************************************************************
 * Function:        void LowDensByteRead(unsigned char data,
 *                                       unsigned int address)
 *
 * Description:     This function performs a byte read operation
 *                  for low-density (<= 4 Kb) devices. It embeds the
 *                  MSb of the memory address into the instruction in
 *                  order to support the 25XX040X.
 *
 * Parameters:      data - Pointer to store byte of data read
 *                  address - Memory location at which to start
 *******************************************************************/
void LowDensByteRead(unsigned char *data, unsigned int address)
{
    static unsigned char command;   // Temp. variable to store cmd.

    // First embed MSb of address (bit 8) into instruction
    command = address >> 5;         // Align MSb of address
    command &= 0x08;                // Mask off extra bits
    command |= READ;                // Merge in READ instruction

    CS = 0;                         // Bring CS low (active)
    byteout(command);               // Output command & MSb of address
    byteout(address&0xFF);          // Output LSB of address
    *data = bytein();               // Read byte of data
    CS = 1;                         // Bring CS high (inactive)
} // end of LowDensByteRead(...)

/********************************************************************
 * Function:        void LowDensPageWrite(unsigned char *data,
 *                                        unsigned int address,
 *                                        unsigned char size)
 *
 * Description:     This function performs a page write operation for
 *                  low-density (<= 4 Kb) devices. It embeds the MSb
 *                  of the memory address into the instruction in
 *                  order to support the 25XX040X. After initiating
 *                  the write cycle, the WIP_Poll function is called
 *                  to determine the end of the cycle. Note that this
 *                  function does not check for page boundary
 *                  violations.
 *
 * Parameters:      data - Byte array of data to be written
 *                  address - Memory location at which to start
 *                  size - Number of bytes to write
 *******************************************************************/
void LowDensPageWrite(unsigned char *data, unsigned int address,
                      unsigned char size)
{
    static unsigned char i;         // Loop counter
    static unsigned char command;   // Temp. variable to store cmd.

    // First embed MSb of address (bit 8) into instruction
    command = address >> 5;         // Align MSb of address
    command &= 0x08;                // Mask off extra bits
    command |= WRITE;               // Merge in WRITE instruction

    WriteEnable();                  // Set WEL bit for write
    CS = 0;                         // Bring CS low (active)
    byteout(command);               // Output command & MSb of address
    byteout(address&0xFF);          // Output LSB of address
    for (i = 0; i < size; i++)      // Loop through number of bytes
    {
        byteout(data[i]);           // Write next byte from array
    }
    CS = 1;                         // Bring CS high (inactive)
    WIP_Poll();                     // Perform WIP polling
} // end of LowDensPageWrite(...)

/********************************************************************
 * Function:        void LowDensSeqRead(unsigned char *data,
 *                                      unsigned int address,
 *                                      unsigned char size)
 *
 * Description:     This function performs a sequential read operation
 *                  for low-density (<= 4 Kb) devices. It embeds the
 *                  MSb of the memory address into the instruction in
 *                  order to support the 25XX040X.
 *
 * Parameters:      data - Array to store data read
 *                  address - Memory location at which to start
 *                  size - Number of bytes to read
 *******************************************************************/
void LowDensSeqRead(unsigned char *data, unsigned int address,
                    unsigned char size)
{
    static unsigned char i;         // Loop counter
    static unsigned char command;   // Temp. variable to store cmd.

    // First embed MSb of address (bit 8) into instruction
    command = address >> 5;         // Align MSb of address
    command &= 0x08;                // Mask off extra bits
    command |= READ;                // Merge in READ instruction

    CS = 0;                         // Bring CS low (active)
    byteout(command);               // Output command & MSb of address
    byteout(address&0xFF);          // Output LSB of address
    for (i = 0; i < size; i++)      // Loop through number of bytes
    {
        data[i] = bytein();         // Read next byte into array
    }
    CS = 1;                         // Bring CS high (inactive)
} // end of LowDensSeqRead(...)

/********************************************************************
 * Function:        void HighDensByteWrite(unsigned char data,
 *                                         unsigned int address)
 *
 * Description:     This function performs a byte write operation for
 *                  high-density (> 4 Kb) devices which feature a
 *                  2-byte address structure. After initiating
 *                  the write cycle, the WIP_Poll function is
 *                  called to determine the end of the cycle. Note
 *                  that this function does not check for page
 *                  boundary violations.
 *
 * Parameters:      data - Byte of data to be written
 *                  address - Memory location at which to start
 *******************************************************************/
void HighDensByteWrite(unsigned char data, unsigned int address)
{
    WriteEnable();                  // Set WEL bit for write
    CS = 0;                         // Bring CS low (active)
    byteout(WRITE);                 // Output WRITE command
    byteout((address>>8)&0xFF);     // Output MSB of address
    byteout(address&0xFF);          // Output LSB of address
    byteout(data);                  // Write byte of data
    CS = 1;                         // Bring CS high (inactive)
    WIP_Poll();                     // Perform WIP polling
} // end of HighDensByteWrite(...)

/********************************************************************
 * Function:        void HighDensByteRead(unsigned char *data,
 *                                        unsigned int address)
 *
 * Description:     This function performs a byte read operation
 *                  for high-density (> 4 Kb) devices which feature a
 *                  2-byte address structure.
 *
 * Parameters:      data - Pointer to store byte of data read
 *                  address - Memory location at which to start
 *******************************************************************/
void HighDensByteRead(unsigned char *data, unsigned int address)
{
    CS = 0;                         // Bring CS low (active)
    byteout(READ);                  // Output READ command
    byteout((address>>8)&0xFF);     // Output MSB of address
    byteout(address&0xFF);          // Output LSB of address
    *data = bytein();               // Read byte of data
    CS = 1;                         // Bring CS high (inactive)
} // end of HighDensByteRead(...)

/********************************************************************
 * Function:        void HighDensPageWrite(unsigned char *data,
 *                                         unsigned int address,
 *                                         unsigned char size)
 *
 * Description:     This function performs a page write operation for
 *                  high-density (> 4 Kb) devices which feature a
 *                  2-byte address structure. After initiating
 *                  the write cycle, the WIP_Poll function is
 *                  called to determine the end of the cycle. Note
 *                  that this function does not check for page
 *                  boundary violations.
 *
 * Parameters:      data - Byte array of data to be written
 *                  address - Memory location at which to start
 *                  size - Number of bytes to write
 *******************************************************************/
void HighDensPageWrite(unsigned char *data, unsigned int address,
                       unsigned char size)
{
    static unsigned char i;         // Loop counter

    WriteEnable();                  // Set WEL bit for write
    CS = 0;                         // Bring CS low (active)
    byteout(WRITE);                 // Output WRITE command
    byteout((address>>8)&0xFF);     // Output MSB of address
    byteout(address&0xFF);          // Output LSB of address
    for (i = 0; i < size; i++)      // Loop through number of bytes
    {
        byteout(data[i]);           // Write next byte from array
    }
    CS = 1;                         // Bring CS high (inactive)
    WIP_Poll();                     // Perform WIP polling
} // end of HighDensPageWrite(...)

/********************************************************************
 * Function:        void HighDensSeqRead(unsigned char *data,
 *                                       unsigned int address,
 *                                       unsigned char size)
 *
 * Description:     This function performs a sequential read operation
 *                  for high-density (> 4 Kb) devices which feature a
 *                  2-byte address structure.
 *
 * Parameters:      data - Array to store data read
 *                  address - Memory location at which to start
 *                  size - Number of bytes to read
 *******************************************************************/
void HighDensSeqRead(unsigned char *data, unsigned int address,
                     unsigned char size)
{
    static unsigned char i;         // Loop counter

    CS = 0;                         // Bring CS low (active)
    byteout(READ);                  // Output READ command
    byteout((address>>8)&0xFF);     // Output MSB of address
    byteout(address&0xFF);          // Output LSB of address
    for (i = 0; i < size; i++)      // Loop through number of bytes
    {
        data[i] = bytein();         // Read next byte into array
    }
    CS = 1;                         // Bring CS high (inactive)
} // end of HighDensSeqRead(...)

/********************************************************************
 * Function:        void WriteStatusReg(unsigned char status)
 *
 * Description:     This function writes the value specified by
 *                  status to the Status Register of a device.
 *                  Note that after performing a WREN instruction, a
 *                  RDSR instruction is executed to check that the
 *                  WEL bit is set. However, currently no error-
 *                  handling is done if the WEL bit is not set.
 *
 * Parameters:      status - Value to be written to Status Register
 *******************************************************************/
void WriteStatusReg(unsigned char status)
{
    WriteEnable();                  // Set WEL bit for write
    CS = 0;                         // Bring CS low (active)
    byteout(WRSR);                  // Output WRSR command
    byteout(status);                // Output value to be written
    CS = 1;                         // Bring CS high (inactive)
    WIP_Poll();                     // Perform WIP polling
} // end of WriteStatusReg(...)

/********************************************************************
 * Function:        unsigned char ReadStatusReg(void)
 *
 * Description:     This function reads and returns the value of the
 *                  Status Register of a device.
 *******************************************************************/
unsigned char ReadStatusReg(void)
{
    unsigned char retval;           // Return value variable

    CS = 0;                         // Bring CS low (active)
    byteout(RDSR);                  // Output RDSR command
    retval = bytein();              // Read Status Register byte
    CS = 1;                         // Bring CS high (inactive)

    return retval;                  // Return value
} // end of ReadStatusReg(void)

/********************************************************************
 * Function:        void WriteEnable(void)
 *
 * Description:     This function performs a Write Enable instruction
 *                  to set the WEL bit in the Status Register.
 *                  Note that after performing the WREN instruction, a
 *                  RDSR instruction is executed to check that the
 *                  WEL bit is set. However, currently no error-
 *                  handling is done if the WEL bit is not set.
 *******************************************************************/
void WriteEnable(void)
{
    static unsigned char status;    // Temp. variable to store status reg.

    CS = 0;                         // Bring CS low (active)
    byteout(WREN);                  // Output WREN command
    CS = 1;                         // Bring CS high (inactive)
    status = ReadStatusReg();       // Check that WEL bit is set
} // end of WriteEnable(void)

/********************************************************************
 * Function:        void WriteDisable(void)
 *
 * Description:     This function performs a Write Disable instruction
 *                  to clear the WEL bit in the Status Register.
 *******************************************************************/
void WriteDisable(void)
{
    CS = 0;                         // Bring CS low (active)
    byteout(WRDI);                  // Output WRDS command
    CS = 1;                         // Bring CS high (inactive)
} // end of WriteDisable(void)

/********************************************************************
 * Function:        void byteout(unsigned char byte)
 *
 * Description:     This function outputs a single byte onto the
 *                  SPI bus, MSb first.
 *******************************************************************/
void byteout(unsigned char byte)
{
    static unsigned char i;         // Loop counter

    SCK = 0;                        // Ensure SCK is low
    for (i = 0; i < 8; i++)         // Loop through each bit
    {
        if (byte & 0x80)            // Check if next bit is a 1
        {
            SO = 1;                 // If a 1, pull SO high
        }
        else
        {
            SO = 0;                 // If a 0, pull SO low
        }
        SCK = 1;                    // Bring SCK high to latch bit
        Nop();                      // Avoid violating Thi
        SCK = 0;                    // Bring SCK low for next bit
        byte = byte << 1;           // Shift byte left for next bit
    }
} // end of byteout(...)

/********************************************************************
 * Function:        unsigned char bytein(void)
 *
 * Description:     This function inputs a single byte from the
 *                  SPI bus, MSb first.
 *******************************************************************/
unsigned char bytein(void)
{
    static unsigned char i;         // Loop counter
    static unsigned char retval;    // Return value

    retval = 0;
    SCK = 0;                        // Ensure SCK is low
    for (i = 0; i < 8; i++)         // Loop through each bit
    {
        retval = retval << 1;       // Shift byte left for next bit
        SCK = 1;                    // Bring SCK high
        if (SI == 1)                // Check if next bit is a 1
        {
            retval |= 0x01;         // If a 1, set next bit to 1
        }
        else
        {
            retval &= 0xFE;         // If a 0, set next bit to 0
        }
        SCK = 0;                    // Bring SCK low for next bit
    }

    return retval;
} // end of bytein(void)

/********************************************************************
 * Function:        void WIP_Poll(void)
 *
 * Description:     This function performs WIP polling to determine
 *                  the end of the current write cycle. It does this
 *                  by continuously executing a Read Status Register
 *                  operation until the WIP bit (bit 0 of the Status
 *                  Register) is read low.
 *******************************************************************/
void WIP_Poll(void)
{
    static unsigned char status;    // Variable to store Status Reg.

    do {
        status = ReadStatusReg();   // Perform RDSR operation
    } while(status & 0x01);         // Loop while WIP (bit 0) is 1
} // end of WIP_Poll(void)
