
/********************************************************************
 *                                                                    
 *                     Software License Agreement                      
 *                                                                     
 * The software supplied herewith by Microchip Technology Incorporated 
 * (the "Company") for its PICmicro� Microcontroller is intended and   
 * supplied to you, the Company�s customer, for use solely and         
 * exclusively on Microchip PICmicro Microcontroller products.         
 *                                                                     
 * The software is owned by the Company and/or its supplier, and is     
 * protected under applicable copyright laws. All rights are reserved.  
 * Any use in violation of the foregoing restrictions may subject the  
 * user to criminal sanctions under applicable laws, as well as to     
 * civil liability for the breach of the terms and conditions of this  
 * license.                                                             
 *                                                                      
 * THIS SOFTWARE IS PROVIDED IN AN "AS IS" CONDITION. NO WARRANTIES,   
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED   
 * TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A         
 * PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,   
 * IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR          
 * CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.                    
 *                                                                     
 *******************************************************************
 *
 *  Filename:           AN1096.c
 *  Date:               May 11, 2007
 *  File Version:       1.0
 *  Compiled using:     MPLAB IDE 7.50.00.0
 *                      MPLAB C30 2.40
 *
 *  Author:             Martin Kvasnicka
 *  Company:            Microchip Technology Inc.
 *
 *******************************************************************
 *
 *  Files required:     AN1096.c
 *                      AN1096_SPI.c
 *                      AN1096.h
 *
 *******************************************************************
 *
 *  Purpose:
 *
 *  This application note is intended to serve as a reference for
 *  manually communicating with Microchip's 25XXXX series serial
 *  EEPROM devices, that is, without relying on a hardware serial
 *  port to handle the SPI operations.
 *
 *******************************************************************
 *
 *  Program Description:
 *
 *  This program illustrates the following operations:
 *   - Low-Density Byte Write
 *   - Low-Density Byte Read
 *   - Low-Density Page Write
 *   - Low-Density Sequential Read
 *   - High-Density Byte Write
 *   - High-Density Byte Read
 *   - High-Density Page Write
 *   - High-Density Sequential Read
 *   - Write Enable
 *   - WIP Polling
 *
 *  In addition, the following operations are available:
 *   - Write Disable
 *   - Read Status Register
 *   - Write Status Register
 *
 *  All low-density operations were tested using the 25LC040. For
 *  the byte operations, the value 0xCC is written to address 0x133
 *  and then read back. For the page operations, a single-page
 *  incrementing pattern is written starting at address 0x150, then
 *  is read back.
 *
 *  All high-density operations were tested using the 25LC256. For
 *  the byte operations, the value 0xCC is written to address 0x00AA
 *  and then read back. For the page operations, a single-page
 *  incrementing pattern is written starting at address 0x5500, then
 *  is read back.
 *
 *  All timings assume a 8 MHz crystal oscillator is used. If a
 *  different crystal frequency is desired, care must be taken to
 *  avoid violating device timing specs.
 *
 *******************************************************************
 *
 *  
 *
 *  Port F Pin Descriptions:
 *
 *  CS             bit = 2
 *  SCK            bit = 6
 *  SO (PIC-side)  bit = 8
 *  SI (PIC-side)  bit = 7
 *
 ** I N C L U D E S ************************************************/
#include <p33fxxxx.h>
#include "AN1096.h"

/** C O N F I G ****************************************************/
_FGS(GSS_OFF & GWRP_OFF);                       //Code Protect off, Write protect disabled
_FOSCSEL(FNOSC_PRIPLL & IESO_OFF & TEMP_OFF);   //Prim. Osc (XT, HS, EC) w/ PLL, Two speed osc off, Temp protect off
_FOSC(FCKSM_CSDCMD & OSCIOFNC_OFF & POSCMD_HS); //Clock Switch & Clock Monitor off, Osc 2 clock, High Speed
_FWDT(FWDTEN_OFF);                              //Watchdog Timer Disabled

#define PAGESIZE    16                          // 16-byte page size for 25XX040

/** P R O T O T Y P E S ********************************************/
void init(void);                                // Init. function

void main(void)
{
    static unsigned char data[PAGESIZE];        // One-page data array
    static unsigned char i;                     // Loop counter

    init();                                     // Initialize PIC

    data[0] = 0xCC;                             // Initialize first data byte

    /* Low-density byte function calls */
    LowDensByteWrite(data[0], 0x133);           // Write 1 byte of data at 0x133
    data[0] = 0xFF;
    LowDensByteRead(data, 0x133);               // Read 1 byte of data at 0x133

//    /* High-density byte function calls */
//    HighDensByteWrite(data[0], 0xAA);         // Write 1 byte of data at 0x00AA
//    data[0] = 0xFF;
//    HighDensByteRead(data, 0xAA);             // Read 1 byte of data at 0x00AA

    for (i = 0; i < PAGESIZE; i++)              // Initialize data array
    {
        data[i] = i;
    }

    /* Low-density page function calls */
    LowDensPageWrite(data, 0x150, PAGESIZE);    // Write 1 page of data starting at 0x150
    for (i = 0; i < PAGESIZE; i++)              // Initialize data array
    {
        data[i] = 0xFF;
    }
    LowDensSeqRead(data, 0x150, PAGESIZE);      // Read 1 page of data starting at 0x150

//    /* High-density page function calls */
//    HighDensPageWrite(data, 0x5500, PAGESIZE);  // Write 1 page of data at 0x5500
//    for (i = 0; i < PAGESIZE; i++)              // Initialize data array
//    {
//        data[i] = 0xFF;
//    }
//    HighDensSeqRead(data, 0x5500, PAGESIZE);    // Read 1 page of data at 0x5500

    while(1){};                                 // Loop here forever
} // end main(void)

/********************************************************************
 * Function:        void init(void)
 *
 * Description:     This function initializes the PICmicro
 *                  microcontroller.
 *******************************************************************/
void init(void)
{
  PORTF = 0x0004;
  TRISF = 0x0080;             
  PLLFBD = 38;                
  CLKDIV = 0x0040;                

} // end init(void)
